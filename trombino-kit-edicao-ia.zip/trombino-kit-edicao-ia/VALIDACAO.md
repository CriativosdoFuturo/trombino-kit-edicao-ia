# Validação da distribuição — 10/09/2026

- Checagem estrutural: 406 cards, duas bibliotecas de estilo, skills sincronizadas; zero erros.
- Testes de scripts: 11 aprovados, zero falhas.
- Dependências instaladas numa nova pasta, usando o cache npm da máquina e scripts de instalação desabilitados.
- Setup confirmou Node 24, FFmpeg e ffprobe; foram reutilizados executáveis já disponíveis na máquina.
- Projeto starter novo renderizado com Chrome instalado: MP4 H.264, 1920 × 1080, 30 fps, oito segundos, sem áudio por projeto; render concluído em 13,4 s nesta máquina.

Esse tempo é uma medição do exemplo sintético nesta máquina, não promessa para outros vídeos ou computadores.

## Ainda não validado

Instalação em computador limpo, transcrição local de fala em português, vídeo falado completo pelo kit, entrega nativa em todos os editores e transparência importada em cada programa. Outra conta no mesmo computador não constitui teste de computador limpo.

## Conteúdo do pacote

O pacote exclui node_modules, ferramentas baixadas, arquivos .env, gravações pessoais, projetos de edição, renders, fontes particulares e perfis pessoais. Dependências são instaladas na máquina do aluno. Os exemplos de marca AIS e vídeos showcase da distribuição original foram omitidos; licenças e créditos foram preservados.

## Edições 2.1

Mudanças desta revisão: documentação de escolha, relatório local de hardware e catálogo opcional. Não há mudança no motor nem nos cards históricos. As novas referências não foram adaptadas nem renderizadas. A validação histórica abaixo/acima não se estende a elas. Computadores modestos ainda não foram certificados.

Checagens desta revisão: sincronização das skills e estrutura aprovadas; 11 testes de scripts aprovados em cada edição; relatório local de hardware executado. Nenhum novo render de efeitos foi realizado nesta revisão.

## Proteção de decupagem conectada

Esta revisão adiciona separação entre instalação e edição, uma tarefa limpa para a primeira decupagem, transcrição única com idioma confirmado, planejamento completo antes da timeline, aplicação em lote, resultados compactos e limite de duas tentativas sem mudança na interface. As skills foram sincronizadas e os 11 testes existentes passaram. Esta revisão não executou uma sessão real do Premiere, DaVinci ou CapCut; a compatibilidade continua dependente da integração instalada.

## Proteção de decupagem 2.1.1

As regras de repetição foram refinadas para não interromper a edição inteira: o limite vale apenas para a mesma ação pelo mesmo método. A skill orienta verificar o estado, trocar de caminho e continuar quando seguro, além de proteger arquivos de projeto em pastas sincronizadas. Mudança documental; nenhum relatório individual de aluno integra esta distribuição.

## J-cut e proteção fonética 2.1.2

A skill exige antecipação real do áudio seguinte para J-cuts e preservação completa de sílabas e fonemas finais antes de remover respirações. O cortador de silêncios inclui `--word-tail-pad 0.16` e um teste automatizado da margem. Mudança validada por testes e checagem estrutural; não houve sessão real de editor nesta revisão.
