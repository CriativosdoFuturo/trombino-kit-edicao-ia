# Decupagem segura e econômica

Use este fluxo para limpar vídeo falado dentro de Premiere, DaVinci ou CapCut por uma integração conectada. Ele reduz repetição, protege a sequência original e evita que a interface seja operada clique por clique sem necessidade.

## Antes de começar

- Termine instalação, diagnóstico e teste sintético na tarefa de preparação.
- Abra uma nova tarefa no mesmo projeto para a edição real.
- Informe somente o caminho da mídia, o projeto do editor, a sequência e o resultado desejado.
- Trabalhe numa duplicata da sequência. Preserve bruto, transcrição e versões anteriores.
- Use somente a integração do editor necessário. Não carregue catálogos de animação numa etapa de cortes.

## Fluxo da decupagem

1. Leia metadados da mídia e da sequência com resultados compactos.
2. Reutilize uma transcrição com tempos se ela corresponder ao vídeo. Caso contrário, confirme o idioma e transcreva uma única vez.
3. Analise a transcrição inteira e produza uma lista fechada de cortes, com início, fim e motivo.
4. Resolva retakes em contexto. A última repetição é uma preferência possível, não uma regra automática.
5. Registre a lista antes de tocar na timeline.
6. Duplique a sequência e aplique os cortes no **modo econômico**, em lote ou no menor número de lotes aceito pela integração.
7. Confira palavras nas bordas, sincronismo, respirações longas e duração final.
8. Salve a nova versão com nome claro e relate somente as decisões e limitações relevantes.

## Modos de execução

### Modo econômico — padrão

Use sempre que o usuário não pedir outra experiência. Aplique a lista em lote ou no menor número de lotes possível e faça uma revisão final. Este é o modo recomendado para reduzir chamadas, tempo e créditos.

### Demonstração visual — somente quando solicitada

Use em aulas ou quando a pessoa quiser acompanhar o Premiere, DaVinci ou CapCut trabalhando. O Codex cria a lista inteira uma única vez e então executa os cortes em ordem, um por um. Cada passo reaproveita o plano fechado e retorna somente um resultado curto. Não volte a analisar o vídeo entre os cortes.

Antes de começar, o Codex deve explicar de forma breve: **“Beleza, vou fazer no modo demonstração visual para você acompanhar os cortes acontecendo. Só para você saber: isso costuma levar mais tempo e gastar mais créditos do que aplicar tudo de uma vez, porque o editor executa cada corte separadamente. Como você pediu esse modo, vou seguir assim.”** O pedido do usuário já escolheu esse modo; depois do aviso, prossiga sem criar outra etapa de confirmação.

Esse modo demora um pouco mais porque o editor recebe mais operações, mas não deve multiplicar o raciocínio nem a transcrição. Não use pausas longas apenas para criar espetáculo. Alguns editores só atualizam a imagem depois de um pequeno grupo de comandos; nesse caso, use poucos blocos verificáveis.

## Limites de repetição

- Prefira o MCP do editor. Use controle visual apenas quando a integração não oferecer a operação necessária.
- Não faça uma nova consulta ao modelo para cada clipe.
- Não imprima todos os esquemas de ferramentas, árvores de acessibilidade ou estados completos da timeline.
- O limite se aplica à mesma ação pelo mesmo método, não à tarefa inteira nem ao objetivo pedido pelo usuário.
- Uma resposta como `There has been no change` significa apenas que a interface não apresentou progresso observável; não prova que a ação falhou. Faça uma verificação independente do estado.
- Se a ação for segura e idempotente, faça no máximo uma segunda tentativa do mesmo método. Se continuar sem evidência, pare de repetir esse método e mude para o MCP, outra inspeção ou outro caminho seguro.
- Para cortes, exclusões e outras ações que podem ser duplicadas, não repita às cegas. Leia primeiro o estado da timeline e só prossiga quando souber se a primeira ação foi aplicada.
- Continue perseguindo o objetivo da edição depois de trocar de método. Peça intervenção do usuário somente quando todos os caminhos disponíveis falharem, o estado estiver incerto ou prosseguir trouxer risco ao projeto.
- Uma operação longa sem progresso útil deve ser interrompida; não mantenha consultas de espera indefinidas.
- Consultas de uma operação longa com progresso confirmado seguem o tempo limite da própria operação e não contam como repetição sem mudança.
- Não retranscreva para corrigir idioma sem confirmar antes o arquivo já produzido e a configuração da próxima tentativa.

## Projetos em pastas sincronizadas

Google Drive, OneDrive e Dropbox podem sincronizar o arquivo do projeto enquanto o editor salva e provocar avisos de alteração externa ou conflitos de versão. Isso não prova que o serviço causou outros erros da edição.

Quando o arquivo do projeto estiver numa dessas pastas:

1. preserve o original sincronizado;
2. crie uma cópia local do arquivo do projeto para a sessão de edição;
3. mantenha os vínculos de mídia existentes quando funcionarem;
4. salve e feche o editor antes de copiar a nova versão de volta para a pasta sincronizada;
5. nunca use a sincronização como motivo para repetir cliques ou consultas sem progresso.

## Prompt para uma tarefa nova

> Use a skill trombino. Quero começar pela decupagem deste vídeo dentro do meu editor no modo econômico. Reutilize uma transcrição existente ou confirme o idioma antes de transcrever. Primeiro produza a lista completa de cortes. Preserve a sequência original numa duplicata e aplique o plano em lote ou no menor número de lotes aceito pela integração. Mantenha os resultados das ferramentas compactos. Use controle visual somente se o MCP não oferecer a operação e abandone a estratégia depois de duas tentativas sem mudança.

Se quiser acompanhar a timeline sendo alterada, acrescente: **“Quero o modo demonstração visual, executando o plano já fechado em ordem, sem reanalisar entre os cortes.”**

O uso do Codex segue o plano da conta. O kit não promete custo ou duração exatos. Modelo, raciocínio e velocidade são escolhas do usuário; não os altere automaticamente.
