# Desempenho e escolha de edição

As edições Essencial e Ampliada têm a mesma base de edição e os mesmos 406 cards históricos em rascunho. A Ampliada acrescenta um catálogo de referências e receitas de adaptação sob demanda. Não contém uma instalação completa de cada demo, nem garante que cada referência já renderize em HyperFrames.

## Começar com a Essencial

Use a Essencial se está começando ou não conhece os limites do computador. Ter muitos arquivos guardados usa disco; executar cenas complexas usa CPU, RAM e GPU. A Ampliada não acelera o render e não é obrigatória para acompanhar as aulas.

Execute `node scripts/machine-report.mjs` para conferir RAM, núcleos lógicos, plataforma e espaço livre quando disponível. O relatório é local e não coleta vídeos ou credenciais. Ele não mede GPU nem certifica desempenho.

Comece com uma prévia de oito segundos em 720p, 30 fps, com um render por vez. Meça o tempo e observe memória e estabilidade. Não aumente o paralelismo automaticamente pelo número de núcleos. Faça depois uma amostra na resolução final: uma prévia em 720p não garante sucesso em 1080p ou 4K.

## Ajustes por cena

- Texto: reduzir área e raio do blur; evitar camadas duplicadas com filtros de tela inteira.
- Cards: usar perspectiva CSS quando suficiente, poucas camadas e imagens dimensionadas para a tela.
- Vidro: começar com transparência, borda e sombra; refração real é uma opção diferente e exige novo teste.
- Partículas e túneis: começar com poucos elementos e resolução interna baixa; aumentar só após medição.
- Física: usar movimento temporizado quando a simulação não é essencial; simulação precisa permitir reprodução determinística para render.
- Mídias: usar proxies nas prévias e considerar fundos pré-renderizados quando a aparência não precisa mudar. Decodificar vídeo também tem custo.

Se houver falha ou lentidão, simplifique a cena escolhida. Não prometa que instalar mais RAM, escolher a Essencial ou usar placa integrada resolverá um problema sem investigar.

## Atualização sem perder projetos

Extraia a nova edição em outra pasta. Preserve a pasta antiga, mídias, `.env` e projetos particulares. Não copie `node_modules` entre versões. Abra a nova pasta no Codex, faça a instalação e o teste antes de levar uma cópia do projeto para ela. Não é necessário usar as duas edições ao mesmo tempo.
