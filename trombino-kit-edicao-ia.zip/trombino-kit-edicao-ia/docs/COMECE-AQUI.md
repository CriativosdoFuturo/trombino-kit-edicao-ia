# Trombino — seu caminho de edição com IA

Comece dizendo: **“Use a skill Trombino para me ajudar a editar este vídeo.”**

O assistente aproveita as informações que você já passou e pergunta o que faltar:

1. Você vai continuar no Premiere, DaVinci ou CapCut, ou quer receber o vídeo pronto?
2. Quer artes para importar, uma montagem completa ou elementos editáveis dentro do editor?
3. Qual vídeo/trecho, formato e referência devemos usar?

## Três maneiras de trabalhar

**Artes para o seu editor.** A IA cria um lettering, gráfico ou insert animado. Você recebe os arquivos separados para colocar sobre sua edição. Se houver uma integração conectada e testada, o assistente também pode colocá-los na timeline. Um render não vira automaticamente texto editável no editor.

**Edição dentro do programa.** O assistente precisa de acesso específico ao editor. No Premiere, isso é uma integração separada do HyperFrames. DaVinci e CapCut precisam de suas próprias verificações. Instalar este kit não conecta os três programas.

**Vídeo pronto por conversa.** Você fornece mídia, roteiro e referências. O Codex cria a composição; HyperFrames renderiza o vídeo. Você revisa a prévia, pede ajustes e recebe um MP4. O Studio é a interface local de prévia e ajustes da composição, não um serviço onde é obrigatório enviar o vídeo.

“Sem editor” significa sem operar Premiere, Resolve ou CapCut. Ainda existe software executando: Codex, HyperFrames, navegador e FFmpeg. A instalação deste kit é voltada ao Codex local; não transforma automaticamente uma conversa comum do ChatGPT em editor conectado ao seu computador.

## O método ensinado no curso

Entender o resultado → analisar/transcrever quando necessário → escolher as falas → montar → planejar as artes no tempo certo → renderizar → assistir e corrigir.

Para uma arte isolada, podemos começar diretamente pelo briefing visual. Para vídeo falado, uma transcrição com tempos ajuda no sincronismo. Serviços de transcrição, geração de imagens, vídeo ou música são opcionais e podem ter custo próprio. O kit não inclui créditos nem chaves de API.

## O que há nas skills

As 14 skills da base cobrem edição, cortes, narrativa, estilos, animação, prévia e exportação. A skill **trombino** acrescenta a entrada do curso e escolhe o caminho de entrega. São instruções e, em alguns casos, scripts auxiliares; não são treinamento do modelo nem conexões automáticas com aplicativos.

O motor e a base didática são projetos de terceiros adaptados para este curso. As licenças e os créditos estão preservados em LICENSE e THIRD_PARTY_NOTICES.md.
