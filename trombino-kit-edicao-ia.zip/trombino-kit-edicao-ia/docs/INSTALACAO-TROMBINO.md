# Instalação e primeiro teste

Este é um kit de projeto, não um instalador universal.

## Dependências

- Node 22+ e npm: https://nodejs.org/en/download
- FFmpeg e ffprobe disponíveis no PATH: https://ffmpeg.org/download.html
- Chrome compatível com a versão instalada do HyperFrames.

No terminal da pasta extraída, após conferir essas dependências:

```sh
npm ci
npm run setup
npm run check
npm test
npm run new-video -- primeiro-teste
npx hyperframes render video-projects/primeiro-teste --output renders/primeiro-teste.mp4 --quality draft --workers 1
```

Se o renderizador não localizar o navegador, peça ao Codex que verifique o Chrome instalado e configure HYPERFRAMES_BROWSER_PATH para aquele executável na sessão. Não copie caminhos de outro computador. O teste não usa API paga nem contém fala; deve gerar um vídeo de oito segundos com texto e cards.

Não desative verificações TLS nem altere permanentemente políticas do computador para contornar erros. Informe a mensagem ao assistente para diagnóstico específico.

## Depois do teste

Encerre a tarefa de instalação e abra uma nova tarefa no mesmo projeto antes da primeira edição real. Isso evita carregar novamente logs de dependências, testes e catálogos de ferramentas em cada operação do editor. Na nova tarefa, peça a entrega desejada usando a skill trombino. Para vídeo falado, escolha e valide a transcrição antes de cortes automáticos. Para editar dentro de um programa, configure a integração correspondente e teste leitura do projeto e uma alteração reversível numa cópia. Conexão ativa não comprova suporte a todos os efeitos. Leia [Decupagem segura e econômica](DECUPAGEM-SEGURA.md).

## Integrações externas

- Premiere: https://github.com/antipaster/Adobe-Premiere-Pro-MCP
- DaVinci, candidato a teste: https://github.com/samuelgursky/davinci-resolve-mcp
- CapCut, experimental e candidato a teste: https://github.com/yabdulaziz2009-dev/capcut-mcp

São projetos comunitários independentes. Instale apenas o necessário. DaVinci e CapCut não foram validados neste curso. Confira requisitos da sua versão, sistema e edição antes da instalação.
