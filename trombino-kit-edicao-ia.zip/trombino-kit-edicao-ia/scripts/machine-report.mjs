import os from 'node:os';
import { statfsSync } from 'node:fs';
let diskFreeGiB = null;
try { const s=statfsSync(process.cwd()); diskFreeGiB=Math.round(s.bavail*s.bsize/2**30); } catch {}
console.log(JSON.stringify({platform:os.platform(),arch:os.arch(),ramGiB:Math.round(os.totalmem()/2**30),availableRamGiB:Math.round(os.freemem()/2**30),logicalCpuCount:os.cpus().length,diskFreeGiB,benchmarkPerformed:false,gpuTested:false,suggestedFirstTest:{height:720,fps:30,durationSeconds:8,concurrentRenders:1}},null,2));
