# Entregas para cada caminho

Esta tabela define opções de trabalho; não certifica compatibilidade de todas as versões dos aplicativos. Inspecione o ambiente real e teste um pequeno arquivo antes de renderizar um lote.

| Destino | Entrega inicial | O que depende de integração ou teste |
| --- | --- | --- |
| Premiere | Inserts e artes renderizadas, fontes da composição e mapa de tempo | Importação/montagem automática exige ponte conectada; MOGRT ou títulos nativos exigem construção própria |
| DaVinci Resolve | Inserts e artes renderizadas, fontes da composição e mapa de tempo | Automação depende da configuração e edição do Resolve; Fusion editável exige composição própria |
| CapCut | Artes renderizadas e instruções de posição/tempo | Testar formato na plataforma utilizada; não prometer projeto nativo ou automação apenas por instalar este kit |
| Sem editor tradicional | MP4 completo, composição HyperFrames e prévia local | Ambiente com Node, navegador e FFmpeg; transcrição e geração de mídia podem exigir ferramentas adicionais |

## Renderizado versus editável

MP4 com H.264 é uma opção inicial para inserts opacos, sujeita ao teste no destino. Texto nele fica incorporado aos pixels. SRT preserva texto e tempo de legendas, mas não os movimentos e estilos de um lettering. O código HTML/GSAP é editável no projeto HyperFrames; não equivale a texto, keyframes ou camadas nativas do editor.

Para sobreposição com fundo transparente, teste uma saída com canal alpha suportada pelo renderizador e pelo editor. WebM transparente não é um formato universal de intercâmbio. MOV ProRes 4444 ou sequência PNG RGBA são candidatos quando o destino aceitar e o fluxo conseguir produzir alpha real; não prometa suporte sem verificar. Converter um vídeo opaco para ProRes 4444 não recupera transparência. Se o destino não aceitar alpha, componha sobre a filmagem previamente ou combine um método de chaveamento, explicando suas limitações.

Máscara retangular/arredondada e recorte do contorno de uma pessoa são operações diferentes. Manter uma pessoa à frente de um insert requer matte/segmentação ou máscara animada; não prometa esse resultado com simples border-radius no HTML. Avalie cabelo, mãos, oclusões e bordas em movimento.

## Pacote para importar

Entregue artes numeradas, prévia sobre a filmagem quando disponível, arquivo-fonte da composição e um CSV/JSON com nome, início, fim e trilha sugerida. Identifique se os tempos se referem ao bruto ou à sequência editada. Use fps da timeline e preserve o mapa entre fonte e edição após cortes.

Confira duração, resolução, fps, alpha quando necessário, sincronismo e ao menos um teste real de importação no editor antes de declarar essa integração validada. Sem acesso ao editor, diga “render verificado; importação ainda não testada”.
