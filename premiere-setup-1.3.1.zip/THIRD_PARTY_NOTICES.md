# Resource provenance

This kit assembles original workspace workflows, design guidance, templates, and
card implementations for students. New pipeline resources exclude private source recordings and private reference
screenshots. The original student kit's previously published example media and
brand assets remain unchanged; their inclusion does not grant third-party rights.

- HyperFrames: https://github.com/heygen-com/hyperframes (Apache-2.0).
  The hyperframes, hyperframes-cli, hyperframes-registry, and gsap skill packages
  were bundled with the original workspace from the HyperFrames skill ecosystem.
  The upstream Apache license is included in licenses/HYPERFRAMES-LICENSE.
- GSAP is installed from npm; its own license applies. See the license files in
  node_modules/gsap and https://gsap.com/community/standard-license/.
- Some library styles reference Google Fonts. Font licenses remain with their
  publishers. Install and preserve applicable licenses when localizing fonts.
- Vox, Kallaway, and Infinite are aesthetic reference names. These templates are
  not official brand assets or endorsed by those creators or organizations.

No blanket relicensing of third-party components is implied. See LICENSE for the
MIT permission for the original student-kit material. Imported pipeline resources
retain the grant in licenses/PIPELINE-USE-PERMISSION.txt. This includes the added
pipeline skills, style library, templates, shared editing tools, and new short-form
workflow. Third-party notices override these grants for their respective assets.

Library names, handles, statistics, and source labels inside cards are illustrative
placeholders. Replace them with your own verified copy before publishing a video.

The three videos in examples/showcase were also explicitly supplied by Nate for
public inclusion as finished-output references. They retain their existing asset
rights; inclusion does not grant rights to third-party brands or embedded media.

## Criativos do Futuro distribution

### Instalador Premiere MCP

- Adobe Premiere Pro MCP 1.2.8: MIT.
- Node.js portátil: distribuição oficial, validada por SHA-256.
- FFmpeg: instalado localmente; aplicam-se as licenças dos componentes do
  binário distribuído.
- whisper.cpp: MIT.
- Modelo Whisper `ggml-small.bin`: baixado do repositório do whisper.cpp e
  validado por SHA-256.

Adaptation: Trombino / Criativos do Futuro. Based on Nate Herk’s HyperFrames Student Kit: https://github.com/nateherkai/hyperframes-student-kit . Original licenses and credits remain. This distribution omits the upstream root AIS assets, branded video-projects, and examples/showcase media described above. It includes no personal footage, fonts, editing profiles, credentials, or paid-service credits. HyperFrames is a third-party engine, not authored by this course.
