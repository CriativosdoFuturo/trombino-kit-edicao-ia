import fs from 'node:fs';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {pipeline} from 'node:stream/promises';
import {Readable} from 'node:stream';
import {createGunzip} from 'node:zlib';
import {fileURLToPath} from 'node:url';
import {checkWindowsIdentity,checkWritableDirectory,checkExistingConfig} from './preflight.mjs';

const here=path.dirname(fileURLToPath(import.meta.url));
const win=process.platform==='win32';
const args=process.argv.slice(2);
const arg=(key,fallback)=>args.includes(key)?args[args.indexOf(key)+1]:fallback;
const root=path.resolve(arg('--root',win?path.join(process.env.LOCALAPPDATA,'CriativosdoFuturo','PremiereMCP'):path.join(os.homedir(),'Library/Application Support/CriativosdoFuturo/PremiereMCP')));
const codex=arg('--codex','codex');
const manifest=JSON.parse(fs.readFileSync(path.join(here,'kit-manifest.json'),'utf8'));
const app=path.join(root,'app');
const tools=path.join(root,'tools');
const cep=win?path.join(process.env.APPDATA,'Adobe/CEP/extensions/MCPBridgeCEP'):path.join(os.homedir(),'Library/Application Support/Adobe/CEP/extensions/MCPBridgeCEP');
const bridge=win?path.join(os.tmpdir(),'premiere-mcp-bridge'):'/tmp/premiere-mcp-bridge';
const configDir=process.env.CODEX_HOME||path.join(os.homedir(),'.codex');
const config=path.join(configDir,'config.toml');
const serverName='premiere_pro_trombino';
const run=(exe,params)=>{
 const r=spawnSync(exe,params,{encoding:'utf8',windowsHide:true,timeout:600000,env:exe===codex?{...process.env,CODEX_HOME:configDir}:process.env});
 if(r.error||r.status!==0) throw new Error(`${path.basename(exe)} falhou (${r.status}): ${r.error?.message||r.stderr?.slice(-1500)||r.stdout?.slice(-1500)}`);
 return r.stdout;
};
const sha=async(file)=>{const h=crypto.createHash('sha256'); for await(const b of fs.createReadStream(file))h.update(b);return h.digest('hex');};
async function download(url,dest,hash){
 if(fs.existsSync(dest)&&await sha(dest)===hash)return;
 const partial=dest+'.partial-'+crypto.randomUUID();
 console.log('Baixando '+path.basename(dest));
 const res=await fetch(url,{signal:AbortSignal.timeout(900000)});
 if(!res.ok)throw new Error('Download HTTP '+res.status+' de '+url);
 await pipeline(Readable.fromWeb(res.body),fs.createWriteStream(partial,{flags:'wx'}));
 if(await sha(partial)!==hash)throw new Error('Integridade divergente: '+partial+'; nada foi executado.');
 await fsp.rename(partial,dest);
}
async function main(){
 if(!['win32','darwin'].includes(process.platform))throw new Error('Execute no computador Windows ou Mac onde o Premiere esta instalado.');
 if(Number(process.versions.node.split('.')[0])<20)throw new Error('Node 20+ necessario.');
 if(!['x64','arm64'].includes(process.arch))throw new Error('Arquitetura nao suportada.');
 checkWindowsIdentity();
 if(win)run('tar.exe',['--version']);
 run(codex,['mcp','add','--help']);
 JSON.parse(run(codex,['mcp','list','--json']));
 if(fs.existsSync(path.join(root,'installation.json'))){
  console.log('Instalacao existente preservada. Execute doctor.mjs e connection.mjs nesta pasta; nao reinstale.');return;
 }
 const existing=spawnSync(codex,['mcp','get',serverName,'--json'],{encoding:'utf8',windowsHide:true,timeout:30000,env:{...process.env,CODEX_HOME:configDir}});
 if(existing.status===0||fs.existsSync(app)||fs.existsSync(cep))throw new Error('EXISTING_INSTALLATION: instalacao ou painel anterior encontrado. Preservado. Diagnosticar a conexao existente antes de migrar; nao substituir automaticamente.');
 for(const target of [root,path.dirname(cep),configDir,bridge])checkWritableDirectory(target);
 checkExistingConfig(config);
 if(args.includes('--preflight')){console.log('PRECHECK_OK: identidade e gravacao de arquivos conferidas; instalacao e conexao ainda nao executadas.');return;}
 fs.mkdirSync(root,{recursive:true});
 const lock=path.join(root,'install.lock');
 const handle=fs.openSync(lock,'wx');fs.closeSync(handle);
 try {
  for(const p of ['downloads','tools','models','transcripts','logs'])fs.mkdirSync(path.join(root,p),{recursive:true});
  const downloads=path.join(root,'downloads');
  const node=path.join(root,win?'runtime/node.exe':'runtime/node');
  fs.mkdirSync(path.dirname(node),{recursive:true});
  if(!fs.existsSync(node))fs.copyFileSync(process.execPath,node,fs.constants.COPYFILE_EXCL);
  if(!win)fs.chmodSync(node,0o755);
  run(node,['--version']);
  let ffmpeg,whisper;
  if(win){
   ffmpeg=path.join(tools,'ffmpeg.exe');whisper=path.join(tools,'whisper-cli.exe');
   const gz=path.join(downloads,'ffmpeg.gz');
   await download('https://github.com/eugeneware/ffmpeg-static/releases/download/b6.1.1/ffmpeg-win32-x64.gz',gz,manifest.ffmpeg['win-x64']);
   if(!fs.existsSync(ffmpeg))await pipeline(fs.createReadStream(gz),createGunzip(),fs.createWriteStream(ffmpeg,{flags:'wx'}));
   const asset=process.arch==='arm64'?'whisper-bin-win-cpu-arm64.zip':'whisper-bin-x64.zip';
   const zip=path.join(downloads,asset);
   await download(`https://github.com/ggml-org/whisper.cpp/releases/download/${manifest.whisper.windowsRelease}/${asset}`,zip,manifest.whisper['win-'+process.arch]);
   const extract=path.join(downloads,'whisper-'+crypto.randomUUID());
   fs.mkdirSync(extract);
   run('tar.exe',['-xf',zip,'-C',extract]);
   function find(dir){for(const ent of fs.readdirSync(dir,{withFileTypes:true})){const f=path.join(dir,ent.name);if(ent.isDirectory()){const found=find(f);if(found)return found;}else if(ent.name==='whisper-cli.exe')return f;}}
   const found=find(extract);if(!found)throw new Error('whisper-cli.exe ausente no pacote oficial.');
   for(const ent of fs.readdirSync(path.dirname(found),{withFileTypes:true}))if(ent.isFile()&&!fs.existsSync(path.join(tools,ent.name)))fs.copyFileSync(path.join(path.dirname(found),ent.name),path.join(tools,ent.name),fs.constants.COPYFILE_EXCL);
  } else {
   const brew=['/opt/homebrew/bin/brew','/usr/local/bin/brew'].find(p=>fs.existsSync(p));
   if(!brew)throw new Error('HOMEBREW_REQUIRED: instalar Homebrew pela fonte oficial e retomar. Nao foi executado script remoto.');
   for(const pkg of ['ffmpeg','whisper-cpp']){
    const r=spawnSync(brew,['list',pkg],{encoding:'utf8'});if(r.status!==0)run(brew,['install',pkg]);
   }
   const prefix=run(brew,['--prefix']).trim();ffmpeg=path.join(prefix,'bin/ffmpeg');whisper=path.join(prefix,'bin/whisper-cli');
  }
  run(ffmpeg,['-version']);run(whisper,['--help']);
  const model=path.join(root,'models',manifest.model.name);
  await download('https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.bin',model,manifest.model.sha256);
  fs.cpSync(path.join(here,'vendor'),app,{recursive:true,errorOnExist:true,force:false});
  const cli=path.join(app,'node_modules/adobe-premiere-pro-mcp/dist/index.js');
  if(args.includes('--prepare-only')){
   fs.writeFileSync(path.join(root,'assets-prepared.json'),JSON.stringify({node,cli,ffmpeg,whisper,model,modelSha256:manifest.model.sha256,hostConfigured:false},null,2));
   console.log('DEPENDENCIAS_PREPARADAS: sem painel instalado nem configuracao alterada.');return;
  }
  const panelSource=path.join(app,'node_modules/adobe-premiere-pro-mcp/cep-plugin');
  fs.mkdirSync(path.dirname(cep),{recursive:true});
  fs.cpSync(panelSource,cep,{recursive:true,errorOnExist:true,force:false});
  // CEP's local development panel requires PlayerDebugMode. Endpoint protection is unchanged.
  const registry=[];
  for(let v=9;v<=15;v++){
   if(win){
    const key=`HKCU\\Software\\Adobe\\CSXS.${v}`;
    const previous=spawnSync('reg.exe',['query',key,'/v','PlayerDebugMode'],{encoding:'utf8',windowsHide:true});
    registry.push({key,previous:previous.stdout||'',status:previous.status});
   } else {
    const key=`com.adobe.CSXS.${v}`;const previous=spawnSync('defaults',['read',key,'PlayerDebugMode'],{encoding:'utf8'});
    registry.push({key,previous:previous.stdout||'',status:previous.status});
   }
  }
  fs.writeFileSync(path.join(root,'cep-settings-before.json'),JSON.stringify(registry,null,2),{flag:'wx'});
  for(const {key} of registry)win?run('reg.exe',['add',key,'/v','PlayerDebugMode','/t','REG_SZ','/d','1','/f']):run('defaults',['write',key,'PlayerDebugMode','1']);
  fs.mkdirSync(bridge,{recursive:true});fs.mkdirSync(configDir,{recursive:true});
  const backup=path.join(root,'logs','codex-config-before.toml');
  if(fs.existsSync(config))fs.copyFileSync(config,backup,fs.constants.COPYFILE_EXCL);
  const env={PREMIERE_TEMP_DIR:bridge,PREMIERE_MCP_TELEMETRY:'0',PREMIERE_MCP_UPDATE_CHECK:'0',PREMIERE_MCP_TOOLSET:'search',PREMIERE_MCP_FFMPEG:ffmpeg,PREMIERE_MCP_WHISPER:whisper,PREMIERE_MCP_WHISPER_MODEL:model,PREMIERE_MCP_TRANSCRIPT_DIR:path.join(root,'transcripts')};
  const flags=Object.entries(env).flatMap(([k,v])=>['--env',`${k}=${v}`]);
  run(codex,['mcp','add',serverName,...flags,'--',node,cli]);
  const saved=JSON.parse(run(codex,['mcp','get',serverName,'--json']));
  if(saved.name!==serverName)throw new Error('Configuracao nao confirmada pelo Codex. Backup preservado.');
  for(const name of ['doctor.mjs','connection.mjs'])fs.copyFileSync(path.join(here,name),path.join(root,name),fs.constants.COPYFILE_EXCL);
  const state={version:manifest.kitVersion,node,cli,ffmpeg,whisper,model,modelSha256:manifest.model.sha256,cep,bridge,env,installedAt:new Date().toISOString(),connectionVerified:false};
  fs.writeFileSync(path.join(root,'installation.json'),JSON.stringify(state,null,2),{flag:'wx'});
  console.log(run(node,[path.join(root,'doctor.mjs')]));
  console.log('INSTALADO. Proxima etapa: connection.mjs --connect (somente leitura). Se necessario, reabra Codex e abra Janela > Extensoes > MCP Bridge no Premiere. Nenhuma edicao de teste necessaria.');
 }finally{fs.unlinkSync(lock);}
}
main().catch(e=>{console.error('INSTALACAO INTERROMPIDA: '+e.message);console.error('Arquivos existentes preservados. Nao remova protecoes nem reinstale em loop.');process.exitCode=1;});
