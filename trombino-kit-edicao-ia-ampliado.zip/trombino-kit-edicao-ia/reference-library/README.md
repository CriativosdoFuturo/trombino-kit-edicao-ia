# Adaptar uma referência para vídeo

Leia `catalog.json` e escolha apenas os itens relevantes ao pedido do aluno. Os nomes selecionados pelo professor são opções do curso, não uma preferência obrigatória dos alunos. Cada item começa como `reference-only`, não como card pronto.

1. Abra a demo e entenda o comportamento escolhido. Confirme texto, duração, proporção, posição do rosto e identidade visual quando faltarem. Não execute todas as demos de uma vez.
2. Consulte a fonte oficial e a licença atual de código e assets. Licença de uso não implica permissão de redistribuir um pacote de código. O item Blur Highlight é Pro: mantenha só o link até haver acesso e licença adequados; não contorne pagamento nem copie código privado. Uma implementação original da ideia geral pode ser proposta sem usar código Pro.
3. Reutilize dependências compatíveis já presentes. Se for necessário React, Three.js ou outro pacote, instale somente no projeto que usa o efeito, respeitando permissões. Não substitua as versões do motor do kit para acomodar uma demo.
4. Crie `DESIGN.md` e uma composição local seguindo a skill HyperFrames. Converta interação em parâmetros animados por uma timeline finita: clique vira instante; mouse vira trajetória; rolagem vira progresso de 0 a 1. Não deixe o vídeo depender de interação real, relógio, rede ou aleatoriedade sem seed.
5. Registre origem, licença, mudanças e arquivos necessários em `REFERENCIAS.md` do projeto. Preserve créditos exigidos. Use imagens e vídeos próprios do aluno, sem copiar as mídias promocionais das demos automaticamente.
6. Teste oito segundos no modo econômico e uma amostra na resolução final. Confira entrada, ponto de maior exposição e saída; compare render com preview. Só então marque uma cópia do modelo como `render-tested`, acompanhada de resolução, fps, máquina e limitações.

## Receitas por comportamento

- Blur Text e Gradual Blur: anime nitidez e opacidade; texto pode usar entradas por palavra. Desfoque progressivo espacial e entrada temporal são efeitos diferentes. Não os troque sem avaliar a referência.
- Animated Content: a seleção do professor usa direção horizontal e escala inicial 1.3. Use apenas como opção, não como regra para todos os vídeos.
- Glow Cursor, Target Cursor, Click Spark, Image Trail e Splash Cursor: substitua o cursor por um ponto virtual com trajetória definida. Use para ilustrar ações do software, não para movimentar o mouse real do aluno.
- Glare Hover, Reflective Card, Specular Button, Fluid Glass e Shape Blur: anime luz, inclinação ou distorção com parâmetros definidos. Escolha a aproximação mais leve que mantenha o resultado aprovado.
- Depth Carousel, Drift Wall, Scroll Stack e Tilted Card: defina número de cards, intervalos e ordem; carregue apenas as mídias usadas. No primeiro teste use imagens, antes de vários vídeos simultâneos.
- Animated List, Option Wheel, Curved Input, Line Sidebar, Card Nav e Bubble Menu: transforme estados de interface em passos didáticos. Use rótulos compreensíveis e não exponha implementação no vídeo.
- Magic Bento, Magic Rings, Magnet Lines, Star Border e Meta Balls: limite o número de formas, a área de filtros e os elementos simultâneos. Star Border foi selecionada; Electric Border não faz parte desta seleção.
- Hyperspeed: trate velocidade, densidade e paleta como parâmetros. Não rode animações paralelas baseadas em requestAnimationFrame sem integração ao tempo do renderizador.
- Origami: a seleção é Pie, Stagger e Coins. Verifique quais objetos e materiais existem na fonte; não suponha que uma versão diferente da biblioteca conserve os mesmos nomes.

## Critérios de entrega

Entregue código editável, assets autorizados, vídeo de teste e relatório de validação. Modelos prontos devem ser separados do catálogo de links. Uma checagem de estrutura ou um benchmark de outra cena não valida todas as referências.
