# Kit Trombino — Como Editar com o ChatGPT

## Edição Ampliada

Mesma base da Essencial, mais 50 referências selecionadas e receitas de adaptação sob demanda. As novas referências não são efeitos já instalados ou testados. Abra reference-library/README.md para escolher.

Leia [edições e desempenho](docs/EDICOES-E-DESEMPENHO.md). Não é necessário baixar as duas edições.


Uma base de trabalho do **Criativos do Futuro** para orientar edição por conversa e criar motion graphics com HyperFrames.

## Comece aqui

1. Instale o aplicativo desktop com acesso ao Codex pelo [guia oficial](https://learn.chatgpt.com/docs/windows/windows-app).
2. Baixe o ZIP pelo botão **BAIXAR KIT TROMBINO** na página do curso no GitHub e extraia a pasta. Se você já está lendo este arquivo dentro da pasta extraída, siga para a próxima etapa.
3. Abra essa pasta como projeto local no Codex. As skills deste kit pertencem ao projeto; abrir outra pasta não as instala automaticamente nela.
4. Cole o pedido abaixo. O assistente verifica as dependências e explica as ações necessárias.

> Leia o README.md e o AGENTS.md deste kit. Prepare esta instalação para criar animações locais com HyperFrames. Confira Node 22 ou superior, npm, FFmpeg, ffprobe e um Chrome compatível; instale o que faltar dentro das permissões disponíveis. Use npm ci, npm run setup e npm run check. Não contrate serviços nem configure APIs pagas. Crie e renderize um teste de oito segundos, confira o resultado e explique o que funcionou e o que ainda falta. Depois use a skill trombino para definir comigo o destino do meu vídeo.

O download do ZIP sozinho não instala o motor nem conecta o Premiere.

## O que você recebe

- 14 skills da base e a skill de entrada `trombino`.
- Biblioteca de 406 cards em HTML/CSS/animação, em estágio de rascunho: pontos de partida para adaptar e revisar.
- Templates de cenas, scripts de edição e exemplos sintéticos.
- Instruções para descobrir o método de cada aluno, sem impor o perfil pessoal do professor.
- Motor HyperFrames instalado como dependência, com versões fixadas pelo package-lock.json.

Leia [COMECE-AQUI](docs/COMECE-AQUI.md) e [instalação e teste](docs/INSTALACAO-TROMBINO.md).

## Escolha sua entrega

**Vídeo pronto:** composição e render local pelo HyperFrames, preservando o código-fonte.

**Artes para importar:** animações separadas para usar no seu editor; transparência depende do formato e precisa ser conferida após a importação.

**Projeto nativo:** depende de uma integração específica do editor. Um vídeo renderizado não se transforma em texto, efeitos e keyframes nativos. Instalar o kit não instala os MCPs.

## Custos e limites

O kit não cobra assinatura própria. O motor tem sua licença de código aberto. O uso do Codex segue o plano e os limites da sua conta; seu editor pode exigir licença. Transcrição, geração de mídia e outros serviços externos podem ter custos e não são necessários para o teste sintético. O script de transcrição herdado usa ElevenLabs: ele não é uma transcrição gratuita já configurada.

## Estado de validação

Na máquina de preparação, o motor renderizou um exemplo sintético de oito segundos, em 1080p/30fps, usando Chrome instalado. Isso não comprova edição integral de vídeo falado, integração nativa em todos os editores ou instalação em um computador limpo. A validação da versão distribuída está em VALIDACAO.md. Execute o teste na sua máquina antes de começar um projeto real.

## Créditos

Adaptação didática por Trombino / Criativos do Futuro, baseada no [HyperFrames Student Kit de Nate Herk](https://github.com/nateherkai/hyperframes-student-kit). O motor [HyperFrames](https://github.com/heygen-com/hyperframes) é um projeto de terceiros. Preservamos LICENSE, THIRD_PARTY_NOTICES.md e licenses/. Marcas e exemplos de terceiros não representam endosso.
