# Kit Trombino — animações com HyperFrames

## Edição única — 2.1.4

Este pacote reúne a base anteriormente chamada Essencial e o catálogo extra da Ampliada. Basta baixar este kit. Os dois endereços antigos passam a entregar o mesmo conteúdo.

Você recebe instruções para o agente, templates, scripts, cards históricos em rascunho e 50 referências extras para adaptação. As referências não são 50 efeitos já implementados ou testados. Consulte o catálogo apenas quando precisar; comece por uma animação simples.

1. Extraia o ZIP. Se já usa o kit, escolha outra pasta e preserve a instalação anterior.
2. Abra a pasta extraída `trombino-kit-edicao-ia` como projeto local no Codex.
3. Envie o pedido abaixo:

> Leia o README.md e o AGENTS.md desta pasta. Prepare o kit para criar animações locais com HyperFrames. Confira as dependências e reaproveite o que já estiver funcionando. Instale o que faltar dentro das permissões disponíveis. Faça o teste inicial de oito segundos em 720p, 30 fps, com um render por vez. Não use APIs pagas. Confira o vídeo gerado e informe o que funcionou e qualquer pendência. Preserve projetos, mídias e configurações existentes.

O download contém a estrutura do projeto; motor e dependências são preparados no computador. Não é um instalador do MCP do Premiere nem uma instalação completa de transcrição local. A integração do editor é separada. Um render pode ser importado como vídeo, mas não vira automaticamente efeitos e textos nativos do editor.

Depois do teste, abra uma nova tarefa na mesma pasta e descreva a animação desejada. Exemplo: “Crie um título animado de cinco segundos com o texto Grave com intenção, fundo escuro, texto claro e entrada suave. Use render local e não use APIs pagas.”

## Histórico e documentação da base

# Kit Trombino — Como Editar com o ChatGPT

Uma base de trabalho do **Criativos do Futuro** para orientar edição por conversa e criar motion graphics com HyperFrames.

## Comece aqui

1. Instale o aplicativo desktop com acesso ao Codex pelo [guia oficial](https://learn.chatgpt.com/docs/windows/windows-app).
2. Baixe o ZIP pelo botão **BAIXAR KIT TROMBINO** na página do curso no GitHub e extraia a pasta. Se você já está lendo este arquivo dentro da pasta extraída, siga para a próxima etapa.
3. Abra essa pasta como projeto local no Codex. As skills deste kit pertencem ao projeto; abrir outra pasta não as instala automaticamente nela.
4. Cole o pedido abaixo. O assistente verifica as dependências e explica as ações necessárias.

> Leia o README.md e o AGENTS.md deste kit. Prepare esta instalação para criar animações locais com HyperFrames. Confira Node 22 ou superior, npm, FFmpeg, ffprobe e um Chrome compatível; instale o que faltar dentro das permissões disponíveis. Use npm ci, npm run setup e npm run check. Não contrate serviços nem configure APIs pagas. Crie e renderize um teste de oito segundos, confira o resultado e explique o que funcionou e o que ainda falta. Depois use a skill trombino para definir comigo o destino do meu vídeo.

O download do ZIP sozinho não instala o motor nem conecta o Premiere.

## Terminou a instalação? Abra uma nova tarefa para editar

Quando o teste de oito segundos terminar, não continue a primeira edição na conversa usada para instalar o kit. Logs, testes e descobertas de ferramentas deixam essa conversa grande e podem aumentar bastante o uso de créditos a cada ação no editor.

1. Clique em **Nova tarefa** no Codex.
2. Abra a mesma pasta do kit como projeto.
3. Informe o caminho do vídeo e do projeto do editor.
4. Cole: **“Use a skill trombino. Quero começar pela decupagem no modo econômico. Reutilize uma transcrição existente ou confirme o idioma antes de transcrever. Planeje todos os cortes antes de alterar a timeline, preserve a sequência original e aplique o plano em lote ou no menor número de lotes possível.”**

Leia [Decupagem segura e econômica](docs/DECUPAGEM-SEGURA.md) antes da primeira edição conectada.

## O que você recebe

- 14 skills da base e a skill de entrada `trombino`.
- Biblioteca de 406 cards em HTML/CSS/animação, em estágio de rascunho: pontos de partida para adaptar e revisar.
- Templates de cenas, scripts de edição e exemplos sintéticos.
- Instruções para descobrir o método de cada aluno, sem impor o perfil pessoal do professor.
- Motor HyperFrames instalado como dependência, com versões fixadas pelo package-lock.json.

Leia [COMECE-AQUI](docs/COMECE-AQUI.md) e [instalação e teste](docs/INSTALACAO-TROMBINO.md).

## Escolha sua entrega

**Vídeo pronto:** composição e render local pelo HyperFrames, preservando o código-fonte.

**Artes para importar:** animações separadas para usar no seu editor; transparência depende do formato e precisa ser conferida após a importação.

**Projeto nativo:** depende de uma integração específica do editor. Um vídeo renderizado não se transforma em texto, efeitos e keyframes nativos. Instalar o kit não instala os MCPs.

## Custos e limites

O kit não cobra assinatura própria. O motor tem sua licença de código aberto. O uso do Codex segue o plano e os limites da sua conta; seu editor pode exigir licença. Transcrição, geração de mídia e outros serviços externos podem ter custos e não são necessários para o teste sintético. O script de transcrição herdado usa ElevenLabs: ele não é uma transcrição gratuita já configurada.

## Estado de validação

Na máquina de preparação, o motor renderizou um exemplo sintético de oito segundos, em 1080p/30fps, usando Chrome instalado. Isso não comprova edição integral de vídeo falado, integração nativa em todos os editores ou instalação em um computador limpo. A validação da versão distribuída está em VALIDACAO.md. Execute o teste na sua máquina antes de começar um projeto real.

## Créditos

Adaptação didática por Trombino / Criativos do Futuro, baseada no [HyperFrames Student Kit de Nate Herk](https://github.com/nateherkai/hyperframes-student-kit). O motor [HyperFrames](https://github.com/heygen-com/hyperframes) é um projeto de terceiros. Preservamos LICENSE, THIRD_PARTY_NOTICES.md e licenses/. Marcas e exemplos de terceiros não representam endosso.

## Atualização 2.1.1 — decupagem conectada

Esta revisão torna o limite de repetição adaptativo: ele vale para a mesma ação pelo mesmo método, não para o objetivo completo da edição. Quando uma interface não demonstra mudança, o Codex verifica o estado, permite uma segunda tentativa segura, troca para o MCP ou outro caminho e continua quando não houver risco. Projetos em Google Drive, OneDrive ou Dropbox recebem orientação para usar uma cópia local do arquivo de projeto durante a edição.

Quem já instalou o MCP do Premiere não precisa reinstalá-lo. Use esta pasta nova como projeto no Codex e preserve a instalação existente do MCP, a pasta anterior, mídias, projetos e configurações pessoais.

## Atualização 2.1.2 — J-cut e finais de palavras

O kit agora diferencia corte apertado de J-cut verdadeiro. Na limpeza comum, remove pausas e respirações indesejadas sem cortar o fonema final. Quando J-cut for solicitado, o áudio seguinte começa antes da troca de imagem e a junção é validada pela forma de onda e pela escuta. O cortador local preserva uma margem fonética de 160 ms por padrão depois dos timestamps de palavras; a escuta prevalece sobre esse número.
