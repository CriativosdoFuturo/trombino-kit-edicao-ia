# Edição única e desempenho

Desde a versão 2.1.4, a distribuição reúne Essencial e Ampliada. O identificador interno `ampliada` foi preservado para compatibilidade com as instruções existentes. Não existe escolha de download a fazer.

A base e o motor permanecem iguais aos da distribuição anterior. As 50 referências extras são um catálogo de inspiração e adaptação sob demanda, não efeitos todos instalados ou testados. Guardar o catálogo não significa executar todas as cenas. O desempenho depende da animação, da resolução e do computador.

Comece com um teste de oito segundos em 720p, 30 fps e um render por vez. Depois teste uma amostra na resolução final. Não aumente o paralelismo apenas pelo número de núcleos. O relatório de hardware não certifica desempenho.

## Ajustes por cena

- Texto: reduzir área e raio do blur; evitar camadas duplicadas com filtros de tela inteira.
- Cards: usar perspectiva CSS quando suficiente, poucas camadas e imagens dimensionadas para a tela.
- Vidro: começar com transparência, borda e sombra; refração real é uma opção diferente e exige novo teste.
- Partículas e túneis: começar com poucos elementos e resolução interna baixa; aumentar só após medição.
- Física: usar movimento temporizado quando a simulação não é essencial; simulação precisa permitir reprodução determinística para render.
- Mídias: usar proxies nas prévias e considerar fundos pré-renderizados quando a aparência não precisa mudar. Decodificar vídeo também tem custo.

Se houver falha ou lentidão, simplifique a cena escolhida. Não prometa que instalar mais RAM, escolher a Essencial ou usar placa integrada resolverá um problema sem investigar.

## Atualização sem perder projetos

Extraia a nova edição em outra pasta. Preserve a pasta antiga, mídias, `.env` e projetos particulares. Não copie `node_modules` entre versões. Abra a nova pasta no Codex, faça a instalação e o teste antes de levar uma cópia do projeto para ela. Não é necessário usar as duas edições ao mesmo tempo.
