# Solução de problemas

## O instalador pede aprovação

É esperado. Aprove somente o script aberto a partir deste kit. O Windows pode
pedir autorização para habilitar o painel CEP no perfil do usuário; o macOS pode
pedir confirmação para executar arquivos baixados.

## O download do Node falhou

Verifique se `https://nodejs.org` abre no navegador e tente novamente. O arquivo
é aceito somente quando o SHA-256 corresponde ao manifesto do kit.

## O painel não aparece no Premiere

Feche o Premiere completamente e abra novamente. Depois procure em
**Janela > Extensões > MCP Bridge (CEP)**. Rode o diagnóstico correspondente ao
sistema se ele continuar ausente.

## O Codex não mostra as ferramentas

Feche completamente o Codex e abra novamente. A configuração fica em
`~/.codex/config.toml` e o instalador salva um backup antes de modificá-la.

## Minhas outras integrações desapareceram

Isso é esperado enquanto o **modo Premiere econômico** estiver ativo. As
integrações continuam instaladas; elas ficam ocultas para impedir que o Codex
carregue catálogos de CapCut, Runway e outros MCPs durante a edição.

Para restaurar:

- Windows: execute `restore-tools.ps1` na pasta instalada indicada pelo relatório.
- macOS: execute `restore-tools-mac.sh` na mesma pasta.

Depois feche completamente e abra novamente o Codex. Para voltar ao Premiere,
execute o script `activate-edit-mode` correspondente e reinicie o Codex.

## O diagnóstico encontra mais de uma integração do Premiere

Não comece a edição. Execute novamente o instalador 1.1.0, reinicie o Codex e
rode o diagnóstico. O modo econômico deve manter somente
`premiere_pro_trombino` ativo. Ele não apaga a integração antiga; apenas a
desativa temporariamente enquanto o Premiere está em uso.

## O painel abriu, mas a conexão falhou

Confira a pasta mostrada ao final da instalação, clique em **Start Bridge** e
peça ao Codex para executar `verify_premiere_connection` sem alterar o projeto.

## Recuperação via npm

Use somente quando o pacote vendorizado estiver danificado e houver Node.js 20+
no sistema.

Windows:

```powershell
npm.cmd install -g adobe-premiere-pro-mcp@1.2.8
premiere-pro-mcp.cmd --install-cep
premiere-pro-mcp.cmd --doctor
```

macOS:

```bash
npm install -g adobe-premiere-pro-mcp@1.2.8
premiere-pro-mcp --install-cep
premiere-pro-mcp --doctor
```
