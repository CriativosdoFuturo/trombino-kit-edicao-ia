# Instalação assistida do Premiere MCP

Este repositório é um instalador para alunos iniciantes. Ao receber o pedido de
instalação, detecte o sistema operacional e execute o script correspondente.
Não mande o aluno editar Registro, PATH, arquivos TOML ou permissões manualmente
antes de rodar o instalador e o diagnóstico.

## Windows

Execute:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
```

## macOS

Execute:

```bash
bash ./install-mac.sh
```

Os scripts instalam em uma pasta estável do perfil do usuário, preservam uma
cópia da configuração do Codex antes de alterá-la e usam o MCP vendorizado em
`vendor/`. Eles não precisam consultar o registro npm no caminho principal.
O instalador também ativa o modo Premiere econômico: preserva
`premiere_pro_trombino`, desativa temporariamente os outros MCPs e apps no
`config.toml` do usuário e grava o estado necessário para restaurá-los. Não
desinstale as integrações anteriores e não substitua esse fluxo por instruções
de prompt; a restrição precisa acontecer na configuração.

Depois que o script terminar, repita literalmente as duas ações manuais
impressas na tela. Aguarde o aluno reiniciar Codex e Premiere, abrir
**MCP Bridge (CEP)** e clicar em **Start Bridge**. Só então execute
`verify_premiere_connection`, sem modificar o projeto.

Antes da primeira edição, confirme no diagnóstico que **Modo Premiere
econômico** aparece como `OK`. Se o aluno terminar de editar e pedir suas outras
ferramentas, execute `restore-tools.ps1` no Windows ou
`restore-tools-mac.sh` no macOS e peça que ele reinicie o Codex. Para uma nova
sessão de Premiere, use o script `activate-edit-mode` correspondente e reinicie.

Se algo falhar, rode `doctor.ps1` no Windows ou `doctor-mac.sh` no macOS e leia
o relatório gerado. Não use APIs pagas, não solicite credenciais de serviços de
voz e não altere projetos do Premiere durante a verificação.
