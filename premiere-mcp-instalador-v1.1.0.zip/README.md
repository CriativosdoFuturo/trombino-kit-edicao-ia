# Instalador Trombino — MCP do Adobe Premiere

Este kit prepara o MCP do Adobe Premiere no **Windows** e no **macOS** a partir
de um único link. Ele foi pensado para alunos iniciantes: o Codex detecta o
sistema, executa o instalador correto, configura o painel CEP e verifica a
instalação.

## Prompt para colar no Codex

> Leia o README.md e o AGENTS.md deste repositório. Detecte se estou no Windows
> ou no Mac e execute o instalador correspondente. Continue até o diagnóstico
> passar. Peça minha intervenção somente quando o sistema exigir aprovação ou
> quando chegar aos dois passos manuais exibidos pelo instalador. Não use APIs
> pagas e não altere nenhum projeto aberto no Premiere.

## O que o kit faz

- instala uma cópia local e versionada do `adobe-premiere-pro-mcp`;
- baixa e valida um Node.js portátil oficial, sem depender do Node do aluno;
- instala o painel **MCP Bridge (CEP)** no perfil do usuário;
- habilita somente as chaves CEP necessárias ao painel;
- registra o servidor no Codex como `premiere_pro_trombino`;
- ativa o **modo Premiere econômico**, mantendo apenas esse MCP visível e ocultando
  temporariamente os outros MCPs, apps e conectores;
- guarda o estado anterior para restaurar as outras ferramentas sem desinstalá-las;
- executa o diagnóstico e grava um relatório local;
- mantém a instalação via npm apenas como recuperação documentada.

Nenhuma API paga é configurada. A instalação não precisa de senha de
administrador na configuração comum.

## Execução manual, se necessário

### Windows

Abra o PowerShell nesta pasta e execute:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
```

### macOS

Abra o Terminal nesta pasta e execute:

```bash
bash ./install-mac.sh
```

## As duas ações do aluno

Quando o instalador terminar, ele mostrará claramente:

1. Feche completamente e abra novamente o Codex e o Premiere.
2. No Premiere, abra **Janela > Extensões > MCP Bridge (CEP)**, confirme a pasta
   indicada e clique em **Start Bridge**.

Depois, no Codex, peça:

> Execute `verify_premiere_connection`. Não altere o projeto.

## Modo Premiere econômico

O modo econômico evita que o Codex carregue catálogos enormes de ferramentas
antes do primeiro corte. Durante a edição no Premiere, apenas
`premiere_pro_trombino` permanece ativo. CapCut, Runway, outros MCPs e apps ficam
temporariamente ocultos, mas continuam instalados.

Quando terminar a edição e quiser suas ferramentas anteriores de volta, peça ao
Codex para executar o script de restauração exibido pelo instalador. Depois,
reinicie o Codex. Para editar novamente no Premiere, execute o script de ativação
instalado na mesma pasta e reinicie o Codex.

O instalador salva um backup do `config.toml` e restaura somente as opções que
ele alterou. Projetos, mídias, credenciais e configurações internas dos outros
MCPs não são apagados.

## Compatibilidade fixada

- Instalador Trombino: `1.1.0`
- MCP do Premiere: `1.2.8`
- Node.js portátil: `24.21.0`
- Requisito declarado pelo MCP: Premiere Pro 2020 ou superior
- Pacotes: Windows x64/ARM64 e macOS Intel/Apple Silicon

Consulte [SUPORTE.md](SUPORTE.md) quando o diagnóstico não passar.
