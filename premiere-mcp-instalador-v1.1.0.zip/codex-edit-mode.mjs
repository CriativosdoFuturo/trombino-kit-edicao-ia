#!/usr/bin/env node

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const args = process.argv.slice(2);
const mode = args[0];
const valueAfter = (flag, fallback) => {
  const index = args.indexOf(flag);
  return index >= 0 && args[index + 1] ? args[index + 1] : fallback;
};

const configPath = path.resolve(valueAfter('--config', path.join(os.homedir(), '.codex', 'config.toml')));
const statePath = path.resolve(valueAfter('--state', path.join(path.dirname(configPath), 'trombino-premiere-mode.json')));
const keepServer = valueAfter('--keep-server', 'premiere_pro_trombino');

function sectionInfo(header) {
  const trimmed = header.trim();
  if (!trimmed.startsWith('mcp_servers.')) return null;
  const tail = trimmed.slice('mcp_servers.'.length);
  const quoted = tail.match(/^(["'])(.*?)\1(?:\.(.*))?$/);
  if (quoted) return { id: quoted[2], root: !quoted[3] };
  const bare = tail.match(/^([A-Za-z0-9_-]+)(?:\.(.*))?$/);
  return bare ? { id: bare[1], root: !bare[2] } : null;
}

function splitSections(text) {
  const newline = text.includes('\r\n') ? '\r\n' : '\n';
  const lines = text.replace(/\r\n/g, '\n').split('\n');
  const sections = [];
  let current = { header: null, start: 0, lines: [] };
  for (let i = 0; i < lines.length; i += 1) {
    const match = lines[i].match(/^\s*\[([^\]]+)\]\s*(?:#.*)?$/);
    if (match) {
      sections.push(current);
      current = { header: match[1], start: i, lines: [lines[i]] };
    } else {
      current.lines.push(lines[i]);
    }
  }
  sections.push(current);
  return { sections, newline };
}

function property(section, key) {
  const pattern = new RegExp(`^\\s*${key}\\s*=\\s*(true|false)\\s*(?:#.*)?$`, 'i');
  for (let i = 1; i < section.lines.length; i += 1) {
    const match = section.lines[i].match(pattern);
    if (match) return { index: i, value: match[1].toLowerCase() };
  }
  return { index: -1, value: 'missing' };
}

function setBoolean(section, key, value) {
  const current = property(section, key);
  const line = `${key} = ${value}`;
  if (current.index >= 0) section.lines[current.index] = line;
  else section.lines.splice(1, 0, line);
  return current.value;
}

function removeBoolean(section, key) {
  const current = property(section, key);
  if (current.index >= 0) section.lines.splice(current.index, 1);
}

function render(sections, newline) {
  return sections.map((section) => section.lines.join(newline)).join(newline);
}

function timestamp() {
  return new Date().toISOString().replace(/[:.]/g, '-');
}

function activate() {
  fs.mkdirSync(path.dirname(configPath), { recursive: true });
  if (!fs.existsSync(configPath)) fs.writeFileSync(configPath, '', 'utf8');
  if (fs.existsSync(statePath)) {
    const existing = JSON.parse(fs.readFileSync(statePath, 'utf8'));
    if (existing.active) {
      console.log('Modo Premiere economico ja esta ativo. Nenhuma configuracao foi sobrescrita.');
      return;
    }
  }

  const original = fs.readFileSync(configPath, 'utf8');
  const backupPath = `${configPath}.backup-premiere-${timestamp()}`;
  fs.copyFileSync(configPath, backupPath);
  const parsed = splitSections(original);
  const state = {
    active: true,
    activatedAt: new Date().toISOString(),
    configPath,
    backupPath,
    keepServer,
    serverChanges: [],
    appsChange: null,
  };

  let features = parsed.sections.find((section) => section.header === 'features');
  if (!features) {
    features = { header: 'features', start: -1, lines: ['[features]'] };
    parsed.sections.push(features);
    state.appsChange = { sectionExisted: false, previous: 'missing' };
  } else {
    state.appsChange = { sectionExisted: true, previous: property(features, 'apps').value };
  }
  setBoolean(features, 'apps', 'false');

  let keptFound = false;
  for (const section of parsed.sections) {
    if (!section.header) continue;
    const info = sectionInfo(section.header);
    if (!info || !info.root) continue;
    const previous = property(section, 'enabled').value;
    if (info.id === keepServer) {
      setBoolean(section, 'enabled', 'true');
      keptFound = true;
      state.serverChanges.push({ id: info.id, previous, target: 'true' });
    } else {
      setBoolean(section, 'enabled', 'false');
      state.serverChanges.push({ id: info.id, previous, target: 'false' });
    }
  }

  if (!keptFound) {
    throw new Error(`Servidor ${keepServer} nao encontrado. Execute o instalador antes de ativar o modo Premiere.`);
  }

  fs.writeFileSync(configPath, render(parsed.sections, parsed.newline), 'utf8');
  fs.writeFileSync(statePath, `${JSON.stringify(state, null, 2)}\n`, 'utf8');
  const disabled = state.serverChanges.filter((item) => item.target === 'false').map((item) => item.id);
  console.log(`Modo Premiere economico ativado. Servidor mantido: ${keepServer}.`);
  console.log(disabled.length ? `Servidores temporariamente desativados: ${disabled.join(', ')}.` : 'Nenhum MCP adicional estava configurado.');
  console.log('Apps e conectores ficaram temporariamente desativados.');
  console.log(`Backup: ${backupPath}`);
}

function restore() {
  if (!fs.existsSync(statePath)) {
    console.log('Nenhum modo Premiere ativo foi encontrado. Nada a restaurar.');
    return;
  }
  const state = JSON.parse(fs.readFileSync(statePath, 'utf8'));
  if (!state.active) {
    console.log('As ferramentas ja foram restauradas.');
    return;
  }
  const current = fs.readFileSync(configPath, 'utf8');
  const parsed = splitSections(current);

  for (const change of state.serverChanges ?? []) {
    const section = parsed.sections.find((candidate) => {
      const info = candidate.header ? sectionInfo(candidate.header) : null;
      return info?.root && info.id === change.id;
    });
    if (!section) continue;
    if (change.previous === 'missing') removeBoolean(section, 'enabled');
    else setBoolean(section, 'enabled', change.previous);
  }

  const features = parsed.sections.find((section) => section.header === 'features');
  if (features && state.appsChange) {
    if (state.appsChange.previous === 'missing') removeBoolean(features, 'apps');
    else setBoolean(features, 'apps', state.appsChange.previous);
    if (!state.appsChange.sectionExisted && features.lines.slice(1).every((line) => !line.trim())) {
      parsed.sections.splice(parsed.sections.indexOf(features), 1);
    }
  }

  fs.writeFileSync(configPath, render(parsed.sections, parsed.newline), 'utf8');
  state.active = false;
  state.restoredAt = new Date().toISOString();
  fs.writeFileSync(statePath, `${JSON.stringify(state, null, 2)}\n`, 'utf8');
  console.log('Ferramentas anteriores restauradas. O MCP premiere_pro_trombino continua instalado.');
}

function status() {
  if (!fs.existsSync(statePath)) {
    console.log('INATIVO');
    process.exitCode = 2;
    return;
  }
  const state = JSON.parse(fs.readFileSync(statePath, 'utf8'));
  console.log(state.active ? 'ATIVO' : 'INATIVO');
  if (!state.active) process.exitCode = 2;
}

try {
  if (mode === 'activate') activate();
  else if (mode === 'restore') restore();
  else if (mode === 'status') status();
  else throw new Error('Uso: codex-edit-mode.mjs activate|restore|status [--config caminho] [--state caminho]');
} catch (error) {
  console.error(`ERRO: ${error.message}`);
  process.exit(1);
}
