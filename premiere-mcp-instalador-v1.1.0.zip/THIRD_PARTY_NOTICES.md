# Third-party notices

This kit redistributes the installed JavaScript files of
`adobe-premiere-pro-mcp` version 1.2.8 and its runtime dependencies. Their
license files are preserved inside `vendor/node_modules`.

- Adobe Premiere Pro MCP: MIT — https://github.com/hetpatel-11/Adobe_Premiere_Pro_MCP
- Node.js portable runtime: downloaded from https://nodejs.org and verified by
  SHA-256 during installation. Node.js license information is included in the
  downloaded official distribution.

Adobe Premiere Pro is an Adobe product. This kit and the upstream MCP project
are independent community tools and are not official Adobe products.

