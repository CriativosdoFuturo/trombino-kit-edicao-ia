#!/usr/bin/env bash
set -euo pipefail

KIT_ROOT="$(cd "$(dirname "$0")" && pwd)"
INSTALL_ROOT="$HOME/Library/Application Support/CriativosdoFuturo/PremiereMCP"
RUNTIME_ROOT="$INSTALL_ROOT/runtime"
APP_ROOT="$INSTALL_ROOT/app"
LOG_ROOT="$INSTALL_ROOT/logs"
BRIDGE_DIR="/tmp/premiere-mcp-bridge"
NODE_VERSION="24.21.0"
MACHINE="$(uname -m)"
if [[ "$MACHINE" == "arm64" ]]; then ARCH="arm64"; EXPECTED="bed7eea5325e1108f32ce5228ddd6a5f0f08a499ee42aa7442aea583702f6057"; else ARCH="x64"; EXPECTED="1462cb3b3046b815cf8ea436d3da450ec1a9f11dac7e5a46b0ada5305d7e8097"; fi
ARCHIVE="node-v${NODE_VERSION}-darwin-${ARCH}.tar.gz"
URL="https://nodejs.org/dist/v${NODE_VERSION}/${ARCHIVE}"
NODE="$RUNTIME_ROOT/bin/node"
CLI="$APP_ROOT/node_modules/adobe-premiere-pro-mcp/dist/cli.js"
MODE_TOOL="$INSTALL_ROOT/codex-edit-mode.mjs"
MODE_STATE="$INSTALL_ROOT/edit-mode-state.json"

mkdir -p "$INSTALL_ROOT" "$LOG_ROOT" "$BRIDGE_DIR"
LOG="$LOG_ROOT/install-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee -a "$LOG") 2>&1

echo "==> Preparando o Node.js portatil oficial"
if [[ ! -x "$NODE" ]]; then
  TMP_ARCHIVE="${TMPDIR:-/tmp}/$ARCHIVE"
  TMP_EXTRACT="$(mktemp -d)"
  curl -fL "$URL" -o "$TMP_ARCHIVE"
  ACTUAL="$(shasum -a 256 "$TMP_ARCHIVE" | awk '{print $1}')"
  [[ "$ACTUAL" == "$EXPECTED" ]] || { echo 'A validacao do Node falhou.'; exit 1; }
  tar -xzf "$TMP_ARCHIVE" -C "$TMP_EXTRACT"
  rm -rf "$RUNTIME_ROOT"
  mv "$TMP_EXTRACT/node-v${NODE_VERSION}-darwin-${ARCH}" "$RUNTIME_ROOT"
  rm -rf "$TMP_EXTRACT" "$TMP_ARCHIVE"
fi
"$NODE" --version
export PATH="$RUNTIME_ROOT/bin:$PATH"
export PREMIERE_TEMP_DIR="$BRIDGE_DIR"

echo "==> Instalando a copia testada do MCP sem acessar o npm"
rm -rf "$APP_ROOT"
mkdir -p "$APP_ROOT"
cp "$KIT_ROOT/vendor/package.json" "$APP_ROOT/"
[[ -f "$KIT_ROOT/vendor/package-lock.json" ]] && cp "$KIT_ROOT/vendor/package-lock.json" "$APP_ROOT/"
cp -R "$KIT_ROOT/vendor/node_modules" "$APP_ROOT/"
[[ -f "$CLI" ]] || { echo 'O servidor MCP vendorizado nao foi encontrado.'; exit 1; }

echo "==> Instalando o painel CEP"
PREMIERE_TEMP_DIR="$BRIDGE_DIR" "$NODE" "$CLI" --install-cep

echo "==> Registrando o servidor no Codex"
CODEX_DIR="$HOME/.codex"
CODEX_CONFIG="$CODEX_DIR/config.toml"
mkdir -p "$CODEX_DIR"
touch "$CODEX_CONFIG"
cp "$CODEX_CONFIG" "$CODEX_CONFIG.backup-$(date +%Y%m%d-%H%M%S)"
if ! grep -q '^\[mcp_servers\.premiere_pro_trombino\]' "$CODEX_CONFIG"; then
cat >> "$CODEX_CONFIG" <<EOF

[mcp_servers.premiere_pro_trombino]
command = '$NODE'
args = ['$CLI']

[mcp_servers.premiere_pro_trombino.env]
PREMIERE_TEMP_DIR = '$BRIDGE_DIR'
PREMIERE_MCP_TELEMETRY = '0'
PREMIERE_MCP_UPDATE_CHECK = '0'
PREMIERE_MCP_TOOLSET = 'search'
EOF
else
  echo 'A entrada premiere_pro_trombino ja existe; foi preservada.'
fi

echo "==> Ativando o modo economico do Premiere"
cp "$KIT_ROOT/codex-edit-mode.mjs" "$MODE_TOOL"
cp "$KIT_ROOT/activate-edit-mode-mac.sh" "$INSTALL_ROOT/activate-edit-mode-mac.sh"
cp "$KIT_ROOT/restore-tools-mac.sh" "$INSTALL_ROOT/restore-tools-mac.sh"
chmod +x "$INSTALL_ROOT/activate-edit-mode-mac.sh" "$INSTALL_ROOT/restore-tools-mac.sh"
"$NODE" "$MODE_TOOL" activate --config "$CODEX_CONFIG" --state "$MODE_STATE"

echo "==> Executando o diagnostico"
PREMIERE_TEMP_DIR="$BRIDGE_DIR" "$NODE" "$CLI" --doctor

cat > "$INSTALL_ROOT/installation.env" <<EOF
PREMIERE_TEMP_DIR=$BRIDGE_DIR
NODE=$NODE
SERVER=$CLI
VERSION=1.2.8
EOF

echo
echo 'INSTALACAO CONCLUIDA'
echo
echo 'AGORA VOCE PRECISA REALIZAR DUAS ACOES:'
echo '1. Feche completamente e abra novamente o Codex e o Premiere.'
echo '2. No Premiere, abra Janela > Extensoes > MCP Bridge (CEP), confirme esta pasta:'
echo "   $BRIDGE_DIR"
echo '   Depois clique em Start Bridge.'
echo
echo 'Ao voltar ao Codex, escreva:'
echo 'Execute verify_premiere_connection. Nao altere o projeto.'
echo
echo 'Enquanto o modo Premiere estiver ativo, os outros MCPs e apps ficam temporariamente ocultos.'
echo 'Quando terminar de editar e quiser suas outras ferramentas de volta, peca ao Codex:'
echo "Execute o script de restauracao em $INSTALL_ROOT/restore-tools-mac.sh e depois me peca para reiniciar o Codex."
echo
echo "Relatorio: $LOG"
