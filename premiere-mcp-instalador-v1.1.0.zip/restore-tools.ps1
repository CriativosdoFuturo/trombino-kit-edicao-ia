$ErrorActionPreference = 'Stop'
$InstallRoot = Join-Path $env:LOCALAPPDATA 'CriativosdoFuturo\PremiereMCP'
$NodeExe = Join-Path $InstallRoot 'runtime\node.exe'
$Tool = Join-Path $InstallRoot 'codex-edit-mode.mjs'
$State = Join-Path $InstallRoot 'edit-mode-state.json'
$Config = Join-Path $env:USERPROFILE '.codex\config.toml'
& $NodeExe $Tool restore --config $Config --state $State
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host 'Feche completamente e abra novamente o Codex para recarregar suas ferramentas.' -ForegroundColor Yellow
