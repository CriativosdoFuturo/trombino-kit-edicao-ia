#!/usr/bin/env bash
set -euo pipefail
INSTALL_ROOT="$HOME/Library/Application Support/CriativosdoFuturo/PremiereMCP"
"$INSTALL_ROOT/runtime/bin/node" "$INSTALL_ROOT/codex-edit-mode.mjs" activate \
  --config "$HOME/.codex/config.toml" --state "$INSTALL_ROOT/edit-mode-state.json"
echo 'Feche completamente e abra novamente o Codex para aplicar o modo.'
