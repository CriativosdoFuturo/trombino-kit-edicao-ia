#!/usr/bin/env bash
set -u
INSTALL_ROOT="$HOME/Library/Application Support/CriativosdoFuturo/PremiereMCP"
NODE="$INSTALL_ROOT/runtime/bin/node"
CLI="$INSTALL_ROOT/app/node_modules/adobe-premiere-pro-mcp/dist/cli.js"
REPORT="$INSTALL_ROOT/diagnostico.txt"
BRIDGE_DIR="/tmp/premiere-mcp-bridge"
{
  [[ -x "$NODE" ]] && echo "[OK] Node portatil - $NODE" || echo "[FALHOU] Node portatil - $NODE"
  [[ -f "$CLI" ]] && echo "[OK] Servidor MCP - $CLI" || echo "[FALHOU] Servidor MCP - $CLI"
  CEP="$HOME/Library/Application Support/Adobe/CEP/extensions/MCPBridgeCEP"
  [[ -d "$CEP" ]] && echo "[OK] Painel CEP - $CEP" || echo "[FALHOU] Painel CEP - $CEP"
  grep -q '^\[mcp_servers\.premiere_pro_trombino\]' "$HOME/.codex/config.toml" 2>/dev/null && echo '[OK] Configuracao do Codex' || echo '[FALHOU] Configuracao do Codex'
  if [[ -x "$NODE" && -f "$CLI" ]]; then PATH="$(dirname "$NODE"):$PATH" PREMIERE_TEMP_DIR="$BRIDGE_DIR" "$NODE" "$CLI" --doctor; fi
} | tee "$REPORT"
echo "Relatorio salvo em: $REPORT"
