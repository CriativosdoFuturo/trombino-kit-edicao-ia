[CmdletBinding()]
param()

$ErrorActionPreference = 'Continue'
$InstallRoot = Join-Path $env:LOCALAPPDATA 'CriativosdoFuturo\PremiereMCP'
$NodeExe = Join-Path $InstallRoot 'runtime\node.exe'
$Cli = Join-Path $InstallRoot 'app\node_modules\adobe-premiere-pro-mcp\dist\cli.js'
$Report = Join-Path $InstallRoot 'diagnostico.txt'

$lines = [System.Collections.Generic.List[string]]::new()
function Check($Name, $Ok, $Detail) {
    $state = if ($Ok) { 'OK' } else { 'FALHOU' }
    $line = "[$state] $Name - $Detail"
    $lines.Add($line)
    Write-Host $line -ForegroundColor $(if ($Ok) { 'Green' } else { 'Red' })
}

Check 'Node portatil' (Test-Path -LiteralPath $NodeExe) $NodeExe
Check 'Servidor MCP' (Test-Path -LiteralPath $Cli) $Cli
$Cep = Join-Path $env:APPDATA 'Adobe\CEP\extensions\MCPBridgeCEP'
Check 'Painel CEP' (Test-Path -LiteralPath $Cep) $Cep
$Config = Join-Path $env:USERPROFILE '.codex\config.toml'
$HasConfig = (Test-Path -LiteralPath $Config) -and ((Get-Content -LiteralPath $Config -Raw) -match '(?m)^\[mcp_servers\.premiere_pro_trombino\]')
Check 'Configuracao do Codex' $HasConfig $Config

if ((Test-Path -LiteralPath $NodeExe) -and (Test-Path -LiteralPath $Cli)) {
    $env:PATH = "$(Split-Path -Parent $NodeExe);$env:PATH"
    & $NodeExe $Cli --doctor 2>&1 | Tee-Object -Variable doctorOutput
    $lines.AddRange([string[]]$doctorOutput)
}
$lines | Set-Content -LiteralPath $Report -Encoding utf8
Write-Host "`nRelatorio salvo em: $Report"
