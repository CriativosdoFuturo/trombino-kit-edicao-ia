[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$KitRoot = $PSScriptRoot
$InstallRoot = Join-Path $env:LOCALAPPDATA 'CriativosdoFuturo\PremiereMCP'
$RuntimeRoot = Join-Path $InstallRoot 'runtime'
$AppRoot = Join-Path $InstallRoot 'app'
$LogRoot = Join-Path $InstallRoot 'logs'
$BridgeDir = Join-Path $env:TEMP 'premiere-mcp-bridge'
$Manifest = Get-Content -LiteralPath (Join-Path $KitRoot 'kit-manifest.json') -Raw | ConvertFrom-Json
$NodeVersion = [string]$Manifest.nodeVersion
$Arch = if ([System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture -eq 'Arm64') { 'arm64' } else { 'x64' }
$ArchiveName = "node-v$NodeVersion-win-$Arch.zip"
$NodeUrl = "https://nodejs.org/dist/v$NodeVersion/$ArchiveName"
$ExpectedHash = [string]$Manifest.node."win-$Arch"
$NodeExe = Join-Path $RuntimeRoot 'node.exe'
$Cli = Join-Path $AppRoot 'node_modules\adobe-premiere-pro-mcp\dist\cli.js'

New-Item -ItemType Directory -Force -Path $InstallRoot, $LogRoot, $BridgeDir | Out-Null
$LogFile = Join-Path $LogRoot ("install-{0}.log" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
Start-Transcript -LiteralPath $LogFile | Out-Null

function Step([string]$Text) { Write-Host "`n==> $Text" -ForegroundColor Cyan }

try {
    Step 'Preparando o Node.js portatil oficial'
    if (-not (Test-Path -LiteralPath $NodeExe)) {
        $TempZip = Join-Path $env:TEMP $ArchiveName
        $TempExtract = Join-Path $env:TEMP ("trombino-node-" + [guid]::NewGuid().ToString('N'))
        Invoke-WebRequest -Uri $NodeUrl -OutFile $TempZip -UseBasicParsing
        $ActualHash = (Get-FileHash -LiteralPath $TempZip -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($ActualHash -ne $ExpectedHash) { throw "A validacao do Node falhou. Download descartado." }
        Expand-Archive -LiteralPath $TempZip -DestinationPath $TempExtract -Force
        $Extracted = Get-ChildItem -LiteralPath $TempExtract -Directory | Select-Object -First 1
        if (Test-Path -LiteralPath $RuntimeRoot) { Remove-Item -LiteralPath $RuntimeRoot -Recurse -Force }
        Move-Item -LiteralPath $Extracted.FullName -Destination $RuntimeRoot
        Remove-Item -LiteralPath $TempExtract -Recurse -Force
        Remove-Item -LiteralPath $TempZip -Force
    }
    & $NodeExe --version
    $env:PATH = "$RuntimeRoot;$env:PATH"
    $env:PREMIERE_TEMP_DIR = $BridgeDir

    Step 'Instalando a copia testada do MCP sem acessar o npm'
    if (Test-Path -LiteralPath $AppRoot) { Remove-Item -LiteralPath $AppRoot -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $AppRoot | Out-Null
    Copy-Item -LiteralPath (Join-Path $KitRoot 'vendor\package.json') -Destination $AppRoot
    Copy-Item -LiteralPath (Join-Path $KitRoot 'vendor\package-lock.json') -Destination $AppRoot -ErrorAction SilentlyContinue
    Copy-Item -LiteralPath (Join-Path $KitRoot 'vendor\node_modules') -Destination $AppRoot -Recurse
    if (-not (Test-Path -LiteralPath $Cli)) { throw 'O servidor MCP vendorizado nao foi encontrado.' }

    Step 'Instalando o painel CEP e habilitando o modo exigido pela Adobe'
    & $NodeExe $Cli --install-cep
    if ($LASTEXITCODE -ne 0) { throw "O instalador CEP terminou com codigo $LASTEXITCODE." }

    Step 'Registrando o servidor no Codex'
    $CodexDir = Join-Path $env:USERPROFILE '.codex'
    $CodexConfig = Join-Path $CodexDir 'config.toml'
    New-Item -ItemType Directory -Force -Path $CodexDir | Out-Null
    if (Test-Path -LiteralPath $CodexConfig) {
        Copy-Item -LiteralPath $CodexConfig -Destination "$CodexConfig.backup-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
        $ConfigText = Get-Content -LiteralPath $CodexConfig -Raw
    } else { $ConfigText = '' }

    if ($ConfigText -notmatch '(?m)^\[mcp_servers\.premiere_pro_trombino\]') {
        $NodeToml = $NodeExe.Replace("'", "''")
        $CliToml = $Cli.Replace("'", "''")
        $BridgeToml = $BridgeDir.Replace("'", "''")
        $Block = @"

[mcp_servers.premiere_pro_trombino]
command = '$NodeToml'
args = ['$CliToml']

[mcp_servers.premiere_pro_trombino.env]
PREMIERE_TEMP_DIR = '$BridgeToml'
PREMIERE_MCP_TELEMETRY = '0'
PREMIERE_MCP_UPDATE_CHECK = '0'
"@
        Add-Content -LiteralPath $CodexConfig -Value $Block -Encoding utf8
        Write-Host 'Codex configurado.' -ForegroundColor Green
    } else {
        Write-Host 'A entrada premiere_pro_trombino ja existe; foi preservada.' -ForegroundColor Yellow
    }

    Step 'Executando o diagnostico'
    & $NodeExe $Cli --doctor
    if ($LASTEXITCODE -ne 0) { throw "O diagnostico terminou com codigo $LASTEXITCODE." }

    @"
PREMIERE_TEMP_DIR=$BridgeDir
NODE=$NodeExe
SERVER=$Cli
VERSION=$($Manifest.premiereMcpVersion)
"@ | Set-Content -LiteralPath (Join-Path $InstallRoot 'installation.env') -Encoding utf8

    Write-Host "`nINSTALACAO CONCLUIDA" -ForegroundColor Green
    Write-Host "`nAGORA VOCE PRECISA REALIZAR DUAS ACOES:" -ForegroundColor Yellow
    Write-Host '1. Feche completamente e abra novamente o Codex e o Premiere.'
    Write-Host '2. No Premiere, abra Janela > Extensoes > MCP Bridge (CEP), confirme esta pasta:'
    Write-Host "   $BridgeDir" -ForegroundColor Cyan
    Write-Host '   Depois clique em Start Bridge.'
    Write-Host "`nAo voltar ao Codex, escreva:"
    Write-Host 'Execute verify_premiere_connection. Nao altere o projeto.' -ForegroundColor Cyan
    Write-Host "`nRelatorio: $LogFile"
} catch {
    Write-Host "`nA INSTALACAO PAROU: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Relatorio: $LogFile"
    Write-Host 'Peca ao Codex para ler o relatorio e executar doctor.ps1.' -ForegroundColor Yellow
    exit 1
} finally {
    Stop-Transcript | Out-Null
}
