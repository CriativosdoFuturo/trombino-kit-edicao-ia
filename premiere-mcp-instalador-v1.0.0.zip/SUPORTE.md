# Solução de problemas

## O instalador pede aprovação

É esperado. Aprove somente o script aberto a partir deste kit. O Windows pode
pedir autorização para habilitar o painel CEP no perfil do usuário; o macOS pode
pedir confirmação para executar arquivos baixados.

## O download do Node falhou

Verifique se `https://nodejs.org` abre no navegador e tente novamente. O arquivo
é aceito somente quando o SHA-256 corresponde ao manifesto do kit.

## O painel não aparece no Premiere

Feche o Premiere completamente e abra novamente. Depois procure em
**Janela > Extensões > MCP Bridge (CEP)**. Rode o diagnóstico correspondente ao
sistema se ele continuar ausente.

## O Codex não mostra as ferramentas

Feche completamente o Codex e abra novamente. A configuração fica em
`~/.codex/config.toml` e o instalador salva um backup antes de modificá-la.

## O painel abriu, mas a conexão falhou

Confira a pasta mostrada ao final da instalação, clique em **Start Bridge** e
peça ao Codex para executar `verify_premiere_connection` sem alterar o projeto.

## Recuperação via npm

Use somente quando o pacote vendorizado estiver danificado e houver Node.js 20+
no sistema.

Windows:

```powershell
npm.cmd install -g adobe-premiere-pro-mcp@1.2.8
premiere-pro-mcp.cmd --install-cep
premiere-pro-mcp.cmd --doctor
```

macOS:

```bash
npm install -g adobe-premiere-pro-mcp@1.2.8
premiere-pro-mcp --install-cep
premiere-pro-mcp --doctor
```

