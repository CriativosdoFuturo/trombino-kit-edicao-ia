#!/usr/bin/env node

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const argv = process.argv.slice(2);
const arg = (name) => {
  const i = argv.indexOf(name);
  if (i < 0 || !argv[i + 1]) throw new Error(`Argumento obrigatorio ausente: ${name}`);
  return path.resolve(argv[i + 1]);
};
const node = arg('--node');
const cli = arg('--cli');
const bridge = arg('--bridge');
const ffmpeg = arg('--ffmpeg');
const whisper = arg('--whisper');
const model = arg('--model');
const transcripts = arg('--transcripts');

const stamp = () => new Date().toISOString().replace(/[:.]/g, '-');
const backup = (file) => {
  if (fs.existsSync(file)) fs.copyFileSync(file, `${file}.backup-trombino-${stamp()}`);
};
const tomlString = (value) => `'${value.replaceAll("'", "''")}'`;

function configureCodex() {
  const dir = path.join(os.homedir(), '.codex');
  const file = path.join(dir, 'config.toml');
  fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(file)) fs.writeFileSync(file, '', 'utf8');
  backup(file);
  let text = fs.readFileSync(file, 'utf8').replace(/\r\n/g, '\n');
  const header = /^\s*\[mcp_servers\.premiere_pro_trombino(?:\.env)?\]\s*$/m;
  while (header.test(text)) {
    const match = header.exec(text);
    const next = text.indexOf('\n[', match.index + 1);
    text = `${text.slice(0, match.index)}${next < 0 ? '' : text.slice(next + 1)}`;
  }
  text = text.trimEnd();
  text += `${text ? '\n\n' : ''}[mcp_servers.premiere_pro_trombino]\n`;
  text += `enabled = true\ncommand = ${tomlString(node)}\nargs = [${tomlString(cli)}]\n\n`;
  text += '[mcp_servers.premiere_pro_trombino.env]\n';
  const env = {
    PREMIERE_TEMP_DIR: bridge,
    PREMIERE_MCP_TELEMETRY: '0',
    PREMIERE_MCP_UPDATE_CHECK: '0',
    PREMIERE_MCP_TOOLSET: 'search',
    PREMIERE_MCP_FFMPEG: ffmpeg,
    PREMIERE_MCP_WHISPER: whisper,
    PREMIERE_MCP_WHISPER_MODEL: model,
    PREMIERE_MCP_TRANSCRIPT_DIR: transcripts,
  };
  for (const [key, value] of Object.entries(env)) text += `${key} = ${tomlString(value)}\n`;
  fs.writeFileSync(file, text, 'utf8');
  console.log(`Codex configurado: ${file}`);
  return file;
}

function claudeConfigPath() {
  if (process.platform === 'darwin') return path.join(os.homedir(), 'Library', 'Application Support', 'Claude', 'claude_desktop_config.json');
  if (process.platform === 'win32') return path.join(process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming'), 'Claude', 'claude_desktop_config.json');
  return path.join(os.homedir(), '.config', 'Claude', 'claude_desktop_config.json');
}

function configureClaude() {
  const file = claudeConfigPath();
  fs.mkdirSync(path.dirname(file), { recursive: true });
  backup(file);
  let data = {};
  if (fs.existsSync(file)) {
    try { data = JSON.parse(fs.readFileSync(file, 'utf8')); }
    catch { throw new Error(`JSON invalido no Claude: ${file}. O original foi preservado.`); }
  }
  data.mcpServers ??= {};
  for (const key of Object.keys(data.mcpServers)) {
    if (/premiere/i.test(key) && key !== 'premiere-pro') delete data.mcpServers[key];
  }
  data.mcpServers['premiere-pro'] = {
    command: node,
    args: [cli],
    env: {
      PREMIERE_TEMP_DIR: bridge,
      PREMIERE_MCP_TELEMETRY: '0',
      PREMIERE_MCP_UPDATE_CHECK: '0',
      PREMIERE_MCP_TOOLSET: 'search',
      PREMIERE_MCP_FFMPEG: ffmpeg,
      PREMIERE_MCP_WHISPER: whisper,
      PREMIERE_MCP_WHISPER_MODEL: model,
      PREMIERE_MCP_TRANSCRIPT_DIR: transcripts,
    },
  };
  fs.writeFileSync(file, `${JSON.stringify(data, null, 2)}\n`, 'utf8');
  console.log(`Claude configurado: ${file}`);
  return file;
}

try {
  for (const required of [node, cli, ffmpeg, whisper, model]) {
    if (!fs.existsSync(required)) throw new Error(`Dependencia ausente: ${required}`);
  }
  const codex = configureCodex();
  const claude = configureClaude();
  console.log(JSON.stringify({ success: true, codex, claude }));
} catch (error) {
  console.error(`ERRO: ${error.message}`);
  process.exit(1);
}
