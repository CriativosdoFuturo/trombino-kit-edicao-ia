#!/usr/bin/env node

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';

const argv = process.argv.slice(2);
const get = (flag, fallback = '') => { const i = argv.indexOf(flag); return i >= 0 ? argv[i + 1] : fallback; };
const expected = {
  node: path.resolve(get('--node')),
  cli: path.resolve(get('--cli')),
  ffmpeg: path.resolve(get('--ffmpeg')),
  whisper: path.resolve(get('--whisper')),
  model: path.resolve(get('--model')),
};
let failed = 0;
const check = (name, ok, detail) => {
  if (!ok) failed += 1;
  console.log(`[${ok ? 'OK' : 'FALHOU'}] ${name} - ${detail}`);
};
const same = (a, b) => path.resolve(a || '').toLowerCase() === path.resolve(b || '').toLowerCase();

for (const [name, file] of Object.entries(expected)) check(name, fs.existsSync(file), file);
if (fs.existsSync(expected.model)) {
  const size = fs.statSync(expected.model).size;
  check('Modelo Whisper completo', size === 487601967, `${size} bytes`);
}
const ff = spawnSync(expected.ffmpeg, ['-version'], { encoding: 'utf8' });
check('FFmpeg executa', ff.status === 0, (ff.stdout || ff.stderr || '').split(/\r?\n/)[0] || 'sem resposta');
const wh = spawnSync(expected.whisper, ['--help'], { encoding: 'utf8' });
check('Whisper executa', wh.status === 0, wh.status === 0 ? 'whisper-cli disponivel' : (wh.error?.message || `codigo ${wh.status}`));

const codexFile = path.join(os.homedir(), '.codex', 'config.toml');
const codex = fs.existsSync(codexFile) ? fs.readFileSync(codexFile, 'utf8') : '';
check('Codex usa Node absoluto', codex.includes(`command = '${expected.node.replaceAll("'", "''")}'`), codexFile);
check('Codex recebeu transcricao local', codex.includes(`PREMIERE_MCP_WHISPER_MODEL = '${expected.model.replaceAll("'", "''")}'`), codexFile);

const claudeFile = process.platform === 'darwin'
  ? path.join(os.homedir(), 'Library', 'Application Support', 'Claude', 'claude_desktop_config.json')
  : path.join(process.env.APPDATA || '', 'Claude', 'claude_desktop_config.json');
let claude = null;
try { claude = JSON.parse(fs.readFileSync(claudeFile, 'utf8'))?.mcpServers?.['premiere-pro']; } catch {}
check('Claude usa Node absoluto', Boolean(claude && same(claude.command, expected.node)), claudeFile);
check('Claude recebeu transcricao local', Boolean(claude && same(claude.env?.PREMIERE_MCP_WHISPER_MODEL, expected.model)), claudeFile);

const domainFile = expected.cli.replace(/[\\/]dist[\\/]cli\.js$/, path.join('dist', 'tools', 'domains', 'index.js'));
const importTest = spawnSync(expected.node, ['--input-type=module', '-e', `import { domainTools } from ${JSON.stringify(pathToFileURL(domainFile).href)}; const names=domainTools.map(x=>x.name); if(!names.includes('transcribe_media')||!names.includes('read_local_transcript')) process.exit(7); console.log(names.length)`], { encoding: 'utf8' });
check('Ferramentas de transcricao no MCP', importTest.status === 0, importTest.status === 0 ? `${importTest.stdout.trim()} ferramentas catalogadas` : (importTest.stderr || `codigo ${importTest.status}`));

console.log(failed ? `DIAGNOSTICO: ${failed} falha(s). Execute novamente o instalador para reparar.` : 'DIAGNOSTICO: tudo pronto para transcricao local e decupagem.');
process.exit(failed ? 1 : 0);
