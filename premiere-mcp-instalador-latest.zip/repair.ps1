& (Join-Path $PSScriptRoot 'install.ps1')
exit $LASTEXITCODE
