[CmdletBinding()]
param()
$ErrorActionPreference='Continue'
$InstallRoot=Join-Path $env:LOCALAPPDATA 'CriativosdoFuturo\PremiereMCP';$Node=Join-Path $InstallRoot 'runtime\node.exe';$Cli=Join-Path $InstallRoot 'app\node_modules\adobe-premiere-pro-mcp\dist\cli.js';$FFmpeg=Join-Path $InstallRoot 'tools\ffmpeg.exe';$Whisper=Join-Path $InstallRoot 'tools\whisper-cli.exe';$Model=Join-Path $InstallRoot 'models\ggml-small.bin';$Report=Join-Path $InstallRoot 'diagnostico.txt';$Core=if(Test-Path (Join-Path $PSScriptRoot 'doctor-core.mjs')){Join-Path $PSScriptRoot 'doctor-core.mjs'}else{Join-Path $InstallRoot 'doctor-core.mjs'}
$out=& $Node $Core --node $Node --cli $Cli --ffmpeg $FFmpeg --whisper $Whisper --model $Model 2>&1;$code=$LASTEXITCODE;$out|Tee-Object -FilePath $Report
$Cep=Join-Path $env:APPDATA 'Adobe\CEP\extensions\MCPBridgeCEP';if(Test-Path $Cep){'[OK] Painel CEP - '+$Cep|Tee-Object -FilePath $Report -Append}else{'[FALHOU] Painel CEP - '+$Cep|Tee-Object -FilePath $Report -Append;$code=1}
Write-Host "Relatorio salvo em: $Report";exit $code
