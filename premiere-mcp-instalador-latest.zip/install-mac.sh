#!/usr/bin/env bash
set -euo pipefail
KIT_ROOT="$(cd "$(dirname "$0")" && pwd)"
INSTALL_ROOT="$HOME/Library/Application Support/CriativosdoFuturo/PremiereMCP"
RUNTIME_ROOT="$INSTALL_ROOT/runtime"; APP_ROOT="$INSTALL_ROOT/app"; MODEL_ROOT="$INSTALL_ROOT/models"; TRANSCRIPT_ROOT="$INSTALL_ROOT/transcripts"; LOG_ROOT="$INSTALL_ROOT/logs"; BRIDGE_DIR="/tmp/premiere-mcp-bridge"
NODE_VERSION="24.21.0"; MACHINE="$(uname -m)"
if [[ "$MACHINE" == "arm64" ]]; then ARCH="arm64"; NODE_HASH="bed7eea5325e1108f32ce5228ddd6a5f0f08a499ee42aa7442aea583702f6057"; else ARCH="x64"; NODE_HASH="1462cb3b3046b815cf8ea436d3da450ec1a9f11dac7e5a46b0ada5305d7e8097"; fi
ARCHIVE="node-v${NODE_VERSION}-darwin-${ARCH}.tar.gz"; NODE="$RUNTIME_ROOT/bin/node"; CLI="$APP_ROOT/node_modules/adobe-premiere-pro-mcp/dist/cli.js"; MODEL="$MODEL_ROOT/ggml-small.bin"; MODE_TOOL="$INSTALL_ROOT/codex-edit-mode.mjs"; MODE_STATE="$INSTALL_ROOT/edit-mode-state.json"
mkdir -p "$INSTALL_ROOT" "$MODEL_ROOT" "$TRANSCRIPT_ROOT" "$LOG_ROOT" "$BRIDGE_DIR"
LOG="$LOG_ROOT/install-$(date +%Y%m%d-%H%M%S).log"; exec > >(tee -a "$LOG") 2>&1
download_checked(){ curl --fail --location --retry 3 "$1" -o "$2"; [[ "$(shasum -a 256 "$2"|awk '{print $1}')" == "$3" ]] || { rm -f "$2"; echo "SHA-256 invalido: $1"; exit 1; }; }

echo '==> Preparando Node.js portatil'
if [[ ! -x "$NODE" ]]; then TMP_ARCHIVE="${TMPDIR:-/tmp}/$ARCHIVE"; TMP_EXTRACT="$(mktemp -d)"; download_checked "https://nodejs.org/dist/v${NODE_VERSION}/${ARCHIVE}" "$TMP_ARCHIVE" "$NODE_HASH"; tar -xzf "$TMP_ARCHIVE" -C "$TMP_EXTRACT"; rm -rf "$RUNTIME_ROOT"; mv "$TMP_EXTRACT/node-v${NODE_VERSION}-darwin-${ARCH}" "$RUNTIME_ROOT"; rm -rf "$TMP_EXTRACT" "$TMP_ARCHIVE"; fi
"$NODE" --version

echo '==> Instalando FFmpeg e Whisper locais pelo Homebrew'
if [[ -x /opt/homebrew/bin/brew ]]; then BREW=/opt/homebrew/bin/brew; elif [[ -x /usr/local/bin/brew ]]; then BREW=/usr/local/bin/brew; else
  echo 'O Homebrew e necessario para os binarios nativos do Mac. O instalador oficial pode pedir a senha do Mac.'
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  if [[ -x /opt/homebrew/bin/brew ]]; then BREW=/opt/homebrew/bin/brew; else BREW=/usr/local/bin/brew; fi
fi
"$BREW" list ffmpeg >/dev/null 2>&1 || "$BREW" install ffmpeg
"$BREW" list whisper-cpp >/dev/null 2>&1 || "$BREW" install whisper-cpp
FFMPEG="$("$BREW" --prefix)/bin/ffmpeg"; WHISPER="$("$BREW" --prefix)/bin/whisper-cli"
[[ -x "$FFMPEG" && -x "$WHISPER" ]] || { echo 'FFmpeg ou whisper-cli ausente depois da instalacao.'; exit 1; }

echo '==> Baixando modelo Whisper small multilingue (uma unica vez)'
if [[ ! -f "$MODEL" || "$(stat -f%z "$MODEL")" != "487601967" ]]; then download_checked 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.bin' "$MODEL.partial" '1be3a9b2063867b937e64e2ec7483364a79917e157fa98c5d94b5c1fffea987b'; mv "$MODEL.partial" "$MODEL"; fi

echo '==> Instalando MCP e painel CEP'
rm -rf "$APP_ROOT"; mkdir -p "$APP_ROOT"; cp "$KIT_ROOT/vendor/package.json" "$APP_ROOT/"; [[ ! -f "$KIT_ROOT/vendor/package-lock.json" ]] || cp "$KIT_ROOT/vendor/package-lock.json" "$APP_ROOT/"; cp -R "$KIT_ROOT/vendor/node_modules" "$APP_ROOT/"; PREMIERE_TEMP_DIR="$BRIDGE_DIR" "$NODE" "$CLI" --install-cep

echo '==> Reparando configuracoes do Codex e Claude'
cp "$KIT_ROOT/codex-edit-mode.mjs" "$MODE_TOOL"; CODEX_CONFIG="$HOME/.codex/config.toml"
if [[ -f "$MODE_STATE" && -f "$CODEX_CONFIG" ]]; then "$NODE" "$MODE_TOOL" restore --config "$CODEX_CONFIG" --state "$MODE_STATE" || true; fi
"$NODE" "$KIT_ROOT/configure-clients.mjs" --node "$NODE" --cli "$CLI" --bridge "$BRIDGE_DIR" --ffmpeg "$FFMPEG" --whisper "$WHISPER" --model "$MODEL" --transcripts "$TRANSCRIPT_ROOT"
"$NODE" "$MODE_TOOL" activate --config "$CODEX_CONFIG" --state "$MODE_STATE"

echo '==> Executando diagnostico completo'
cp "$KIT_ROOT/doctor-mac.sh" "$KIT_ROOT/doctor-core.mjs" "$KIT_ROOT/activate-edit-mode-mac.sh" "$KIT_ROOT/restore-tools-mac.sh" "$INSTALL_ROOT/"; chmod +x "$INSTALL_ROOT"/*.sh
bash "$KIT_ROOT/doctor-mac.sh"
cat > "$INSTALL_ROOT/installation.env" <<EOF
PREMIERE_TEMP_DIR=$BRIDGE_DIR
NODE=$NODE
SERVER=$CLI
FFMPEG=$FFMPEG
WHISPER=$WHISPER
MODEL=$MODEL
VERSION=1.2.0
EOF
echo; echo 'INSTALACAO/REPARO CONCLUIDO'; echo '1. Feche completamente e abra novamente o Codex ou Claude e o Premiere.'; echo '2. No Premiere, abra Janela > Extensoes > MCP Bridge (CEP), confirme a pasta e clique em Start Bridge:'; echo "   $BRIDGE_DIR"; echo 'Depois execute verify_premiere_connection. A transcricao local ja esta instalada.'; echo "Relatorio: $LOG"
