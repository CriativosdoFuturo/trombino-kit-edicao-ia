[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$KitRoot=$PSScriptRoot; $InstallRoot=Join-Path $env:LOCALAPPDATA 'CriativosdoFuturo\PremiereMCP'; $RuntimeRoot=Join-Path $InstallRoot 'runtime'; $AppRoot=Join-Path $InstallRoot 'app'; $ToolsRoot=Join-Path $InstallRoot 'tools'; $ModelRoot=Join-Path $InstallRoot 'models'; $TranscriptRoot=Join-Path $InstallRoot 'transcripts'; $LogRoot=Join-Path $InstallRoot 'logs'; $BridgeDir=Join-Path $env:TEMP 'premiere-mcp-bridge'
$Manifest=Get-Content (Join-Path $KitRoot 'kit-manifest.json') -Raw|ConvertFrom-Json; $NodeVersion=[string]$Manifest.nodeVersion; $Arch=if([Runtime.InteropServices.RuntimeInformation]::OSArchitecture -eq 'Arm64'){'arm64'}else{'x64'}
$NodeArchive="node-v$NodeVersion-win-$Arch.zip"; $NodeExe=Join-Path $RuntimeRoot 'node.exe'; $Cli=Join-Path $AppRoot 'node_modules\adobe-premiere-pro-mcp\dist\cli.js'; $FFmpeg=Join-Path $ToolsRoot 'ffmpeg.exe'; $Whisper=Join-Path $ToolsRoot 'whisper-cli.exe'; $Model=Join-Path $ModelRoot ([string]$Manifest.model.name); $ModeTool=Join-Path $InstallRoot 'codex-edit-mode.mjs'; $ModeState=Join-Path $InstallRoot 'edit-mode-state.json'
New-Item -ItemType Directory -Force -Path $InstallRoot,$ToolsRoot,$ModelRoot,$TranscriptRoot,$LogRoot,$BridgeDir|Out-Null; $LogFile=Join-Path $LogRoot ("install-{0}.log" -f (Get-Date -Format 'yyyyMMdd-HHmmss')); Start-Transcript $LogFile|Out-Null
function Step([string]$Text){Write-Host "`n==> $Text" -ForegroundColor Cyan}
function Download-Checked([string]$Url,[string]$Destination,[string]$Hash){Invoke-WebRequest $Url -OutFile $Destination -UseBasicParsing; $Actual=(Get-FileHash $Destination -Algorithm SHA256).Hash.ToLowerInvariant(); if($Actual -ne $Hash.ToLowerInvariant()){Remove-Item $Destination -Force; throw "SHA-256 invalido em $Url"}}
try{
 Step 'Preparando Node.js portatil oficial'
 if(-not(Test-Path $NodeExe)){$Zip=Join-Path $env:TEMP $NodeArchive;$Extract=Join-Path $env:TEMP ("trombino-node-"+[guid]::NewGuid().ToString('N'));Download-Checked "https://nodejs.org/dist/v$NodeVersion/$NodeArchive" $Zip ([string]$Manifest.node."win-$Arch");Expand-Archive $Zip $Extract -Force;if(Test-Path $RuntimeRoot){Remove-Item $RuntimeRoot -Recurse -Force};Move-Item (Get-ChildItem $Extract -Directory|Select-Object -First 1).FullName $RuntimeRoot;Remove-Item $Extract -Recurse -Force;Remove-Item $Zip -Force}; & $NodeExe --version
 Step 'Instalando FFmpeg local'
 if(-not(Test-Path $FFmpeg)){$Gz=Join-Path $env:TEMP 'trombino-ffmpeg.exe.gz';Download-Checked 'https://github.com/eugeneware/ffmpeg-static/releases/download/b6.1.1/ffmpeg-win32-x64.gz' $Gz ([string]$Manifest.ffmpeg.'win-x64');$input=[IO.File]::OpenRead($Gz);$gzip=[IO.Compression.GzipStream]::new($input,[IO.Compression.CompressionMode]::Decompress);$output=[IO.File]::Create($FFmpeg);try{$gzip.CopyTo($output)}finally{$output.Dispose();$gzip.Dispose();$input.Dispose()};Remove-Item $Gz -Force}
 Step 'Instalando Whisper local'
 if(-not(Test-Path $Whisper)){$Asset=if($Arch -eq 'arm64'){'whisper-bin-win-cpu-arm64.zip'}else{'whisper-bin-x64.zip'};$Zip=Join-Path $env:TEMP $Asset;$Extract=Join-Path $env:TEMP ("trombino-whisper-"+[guid]::NewGuid().ToString('N'));Download-Checked "https://github.com/ggml-org/whisper.cpp/releases/download/$($Manifest.whisper.windowsRelease)/$Asset" $Zip ([string]$Manifest.whisper."win-$Arch");Expand-Archive $Zip $Extract -Force;$Candidate=Get-ChildItem $Extract -Recurse -File|Where-Object{$_.Name -in @('whisper-cli.exe','main.exe')}|Select-Object -First 1;if(-not $Candidate){throw 'whisper-cli.exe nao encontrado no pacote oficial.'};Copy-Item (Join-Path $Candidate.Directory.FullName '*') $ToolsRoot -Recurse -Force;if($Candidate.Name -eq 'main.exe'){Copy-Item $Candidate.FullName $Whisper -Force};Remove-Item $Extract -Recurse -Force;Remove-Item $Zip -Force}
 Step 'Baixando modelo Whisper small multilingue (uma unica vez)'
 if(-not(Test-Path $Model) -or (Get-Item $Model).Length -ne [long]$Manifest.model.bytes){$Partial="$Model.partial";Download-Checked 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.bin' $Partial ([string]$Manifest.model.sha256);Move-Item $Partial $Model -Force}
 Step 'Instalando MCP e painel CEP'
 if(Test-Path $AppRoot){Remove-Item $AppRoot -Recurse -Force};New-Item -ItemType Directory -Force $AppRoot|Out-Null;Copy-Item (Join-Path $KitRoot 'vendor\package.json') $AppRoot;Copy-Item (Join-Path $KitRoot 'vendor\package-lock.json') $AppRoot -ErrorAction SilentlyContinue;Copy-Item (Join-Path $KitRoot 'vendor\node_modules') $AppRoot -Recurse;& $NodeExe $Cli --install-cep
 Step 'Reparando configuracoes do Codex e Claude'
 Copy-Item (Join-Path $KitRoot 'codex-edit-mode.mjs') $ModeTool -Force;$CodexConfig=Join-Path $env:USERPROFILE '.codex\config.toml';if((Test-Path $ModeState)-and(Test-Path $CodexConfig)){& $NodeExe $ModeTool restore --config $CodexConfig --state $ModeState}; & $NodeExe (Join-Path $KitRoot 'configure-clients.mjs') --node $NodeExe --cli $Cli --bridge $BridgeDir --ffmpeg $FFmpeg --whisper $Whisper --model $Model --transcripts $TranscriptRoot;if($LASTEXITCODE -ne 0){throw 'Falha ao configurar os clientes.'};& $NodeExe $ModeTool activate --config $CodexConfig --state $ModeState
 Step 'Executando diagnostico completo'
 Copy-Item (Join-Path $KitRoot 'doctor.ps1') $InstallRoot -Force;Copy-Item (Join-Path $KitRoot 'doctor-core.mjs') $InstallRoot -Force;Copy-Item (Join-Path $KitRoot 'activate-edit-mode.ps1') $InstallRoot -Force;Copy-Item (Join-Path $KitRoot 'restore-tools.ps1') $InstallRoot -Force;& powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $KitRoot 'doctor.ps1');if($LASTEXITCODE -ne 0){throw 'O diagnostico encontrou uma falha.'}
 @" 
PREMIERE_TEMP_DIR=$BridgeDir
NODE=$NodeExe
SERVER=$Cli
FFMPEG=$FFmpeg
WHISPER=$Whisper
MODEL=$Model
VERSION=$($Manifest.kitVersion)
"@|Set-Content (Join-Path $InstallRoot 'installation.env') -Encoding utf8
 Write-Host "`nINSTALACAO/REPARO CONCLUIDO" -ForegroundColor Green;Write-Host '1. Feche completamente e abra novamente o Codex ou Claude e o Premiere.' -ForegroundColor Yellow;Write-Host '2. No Premiere, abra Janela > Extensoes > MCP Bridge (CEP), confirme a pasta abaixo e clique em Start Bridge:';Write-Host "   $BridgeDir" -ForegroundColor Cyan;Write-Host 'Depois execute verify_premiere_connection. A transcricao local ja esta instalada.';Write-Host "Relatorio: $LogFile"
}catch{Write-Host "`nA INSTALACAO PAROU: $($_.Exception.Message)" -ForegroundColor Red;Write-Host "Relatorio: $LogFile";exit 1}finally{Stop-Transcript|Out-Null}
