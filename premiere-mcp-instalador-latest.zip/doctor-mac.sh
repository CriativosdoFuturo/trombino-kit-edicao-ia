#!/usr/bin/env bash
set -u
INSTALL_ROOT="$HOME/Library/Application Support/CriativosdoFuturo/PremiereMCP"
NODE="$INSTALL_ROOT/runtime/bin/node"; CLI="$INSTALL_ROOT/app/node_modules/adobe-premiere-pro-mcp/dist/cli.js"; MODEL="$INSTALL_ROOT/models/ggml-small.bin"; REPORT="$INSTALL_ROOT/diagnostico.txt"
if [[ -x /opt/homebrew/bin/brew ]]; then PREFIX=/opt/homebrew; else PREFIX=/usr/local; fi
FFMPEG="$PREFIX/bin/ffmpeg"; WHISPER="$PREFIX/bin/whisper-cli"; CORE="$(cd "$(dirname "$0")" && pwd)/doctor-core.mjs"
"$NODE" "$CORE" --node "$NODE" --cli "$CLI" --ffmpeg "$FFMPEG" --whisper "$WHISPER" --model "$MODEL" 2>&1 | tee "$REPORT"; CODE=${PIPESTATUS[0]}
CEP="$HOME/Library/Application Support/Adobe/CEP/extensions/MCPBridgeCEP"
if [[ -d "$CEP" ]]; then echo "[OK] Painel CEP - $CEP" | tee -a "$REPORT"; else echo "[FALHOU] Painel CEP - $CEP" | tee -a "$REPORT"; CODE=1; fi
echo "Relatorio salvo em: $REPORT"; exit "$CODE"
