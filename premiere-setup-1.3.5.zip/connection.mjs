import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
import readline from 'node:readline';
const root=path.dirname(fileURLToPath(import.meta.url));
const s=JSON.parse(fs.readFileSync(path.join(root,'installation.json'),'utf8'));
const child=spawn(s.node,[s.cli],{env:{...process.env,...s.env},stdio:['pipe','pipe','pipe'],windowsHide:true});
let id=0;const pending=new Map();let diagnostics='';
child.stderr.on('data',b=>{diagnostics=(diagnostics+b.toString()).slice(-3000);});
const rejectAll=e=>{for(const p of pending.values()){clearTimeout(p.timer);p.reject(e);}pending.clear();};
child.on('error',rejectAll);child.on('exit',code=>rejectAll(new Error('Servidor encerrou: '+code)));
readline.createInterface({input:child.stdout}).on('line',line=>{
 try{const msg=JSON.parse(line);const p=pending.get(msg.id);if(!p)return;pending.delete(msg.id);clearTimeout(p.timer);msg.error?p.reject(new Error(msg.error.message)):p.resolve(msg.result);}catch{}
});
function rpc(method,params,timeout=15000){return new Promise((resolve,reject)=>{const n=++id;const timer=setTimeout(()=>{pending.delete(n);reject(new Error('Tempo excedido: '+method));},timeout);pending.set(n,{resolve,reject,timer});child.stdin.write(JSON.stringify({jsonrpc:'2.0',id:n,method,params})+'\n');});}
const report={timestamp:new Date().toISOString(),catalog:false,connection:false,readAccess:false,editsPerformed:false};
function payload(result){const text=(result.content||[]).filter(c=>c.type==='text').map(c=>c.text).join('\n');try{return JSON.parse(text);}catch{return null;}}
try{
 await rpc('initialize',{protocolVersion:'2025-03-26',clientInfo:{name:'trombino-readiness',version:'1.3.5'},capabilities:{}});
 child.stdin.write(JSON.stringify({jsonrpc:'2.0',method:'notifications/initialized'})+'\n');
 const list=await rpc('tools/list',{});const names=list.tools.map(t=>t.name);
 report.catalog=['verify_premiere_connection','list_sequences','search_tools','get_tool_schema','invoke_tool'].every(n=>names.includes(n));
 if(!report.catalog)throw new Error('Catalogo MCP incompleto.');
 const schema=await rpc('tools/call',{name:'get_tool_schema',arguments:{name:'transcribe_media'}});
 report.transcriptionCatalog=!schema.isError&&payload(schema)?.success===true;
 if(process.argv.includes('--connect')){
  const verify=await rpc('tools/call',{name:'verify_premiere_connection',arguments:{}},65000);report.connectionResult=verify;
  const data=payload(verify);
  report.connection=!verify.isError && data?.success===true&&data?.status==='connected';
  if(report.connection){const result=await rpc('tools/call',{name:'list_sequences',arguments:{}});report.readResult=result;report.readAccess=!result.isError&&payload(result)?.success===true;}
 }
 report.ready=report.catalog&&report.transcriptionCatalog&&report.connection&&report.readAccess;
 console.log(JSON.stringify(report,null,2));fs.writeFileSync(path.join(root,'readiness.json'),JSON.stringify(report,null,2));
 if(process.argv.includes('--connect')&&!report.ready)process.exitCode=2;
}catch(e){report.ready=false;report.error=e.message;fs.writeFileSync(path.join(root,'readiness.json'),JSON.stringify(report,null,2));console.error(e.message);console.error(diagnostics);process.exitCode=1;}finally{child.kill();}
