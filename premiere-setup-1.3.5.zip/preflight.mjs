import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';

export function validateIdentity(identity) {
 if (!identity || !identity.trim()) throw new Error('IDENTITY_UNAVAILABLE: nao foi possivel confirmar a conta de execucao.');
 const account=identity.trim().split('\\').at(-1);
 if (/^codexsandbox/i.test(account)) throw new Error('RESTRICTED_EXECUTION: o instalador esta executando na conta restrita '+account+'. Solicite ao cliente uma execucao autorizada na conta do usuario do Premiere. Se indisponivel, entregue o instalador para execucao manual nessa conta. Nao altere ACLs, antivirus ou politicas para contornar a restricao. Nenhuma instalacao iniciada.');
}

export function checkWindowsIdentity() {
 if(process.platform!=='win32')return;
 const r=spawnSync('whoami.exe',[],{encoding:'utf8',windowsHide:true,timeout:10000});
 if(r.status!==0)throw new Error('IDENTITY_UNAVAILABLE: whoami falhou; nenhuma instalacao iniciada.');
 validateIdentity(r.stdout);
}

export function checkWritableDirectory(target) {
 let parent=path.resolve(target);
 while(!fs.existsSync(parent)){
  const next=path.dirname(parent);
  if(next===parent)throw new Error('DIRECTORY_UNAVAILABLE: '+target);
  parent=next;
 }
 const probe=path.join(parent,'.trombino-write-check-'+crypto.randomUUID());
 let created=false;
 try{const fd=fs.openSync(probe,'wx');created=true;fs.closeSync(fd);}
 catch(e){throw new Error('WRITE_PERMISSION_REQUIRED: '+target+' ('+e.code+'). Nenhuma instalacao iniciada.');}
 finally{if(created)fs.unlinkSync(probe);}
}

export function checkExistingConfig(file) {
 if(!fs.existsSync(file))return;
 let fd;
 try{fd=fs.openSync(file,'r+');}
 catch(e){throw new Error('CONFIG_PERMISSION_REQUIRED: '+file+' ('+e.code+'). Configuracao preservada.');}
 finally{if(fd!==undefined)fs.closeSync(fd);}
}

// Ask Windows for write-capable handles without creating keys or changing values.
// A successful check is not a guarantee against later policy changes; writes still fail closed.
export function checkWindowsRegistryAccess(runner=spawnSync) {
 if(process.platform!=='win32')return;
 const script=`$ErrorActionPreference='Stop'; try {
  foreach ($v in 9..15) {
   $target='Software\\Adobe\\CSXS.'+$v; $candidate=$target;
   while ($true) {
    $read=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($candidate,$false);
    if ($null -ne $read) { $read.Close(); break }
    $at=$candidate.LastIndexOf('\\'); if ($at -lt 0) { throw 'No existing registry parent' }; $candidate=$candidate.Substring(0,$at);
   }
   $write=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($candidate,$true);
   if ($null -eq $write) { throw ('Access denied: HKCU\\'+$target) }; $write.Close();
  }
  Write-Output 'REGISTRY_ACCESS_OK'; exit 0
 } catch { [Console]::Error.WriteLine($_.Exception.Message); exit 1 }`;
 const r=runner('powershell.exe',['-NoProfile','-NonInteractive','-Command',script],{encoding:'utf8',windowsHide:true,timeout:20000});
 if(r.error||r.status!==0||!r.stdout?.includes('REGISTRY_ACCESS_OK'))throw Error('REGISTRY_PERMISSION_REQUIRED: acesso de gravacao HKCU/Adobe indisponivel na conta atual. Nenhum valor alterado. Use a autorizacao normal do cliente ou suporte da maquina; nao altere ACLs/politicas. '+(r.error?.message||r.stderr||''));
}
