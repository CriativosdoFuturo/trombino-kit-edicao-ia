import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import {gunzipSync} from 'node:zlib';
import {spawnSync} from 'node:child_process';

export const digest = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
export async function fileHash(file) {
 const h=crypto.createHash('sha256');
 for await(const b of fs.createReadStream(file))h.update(b);
 return h.digest('hex');
}
export function assertPlainTree(root) {
 const st=fs.lstatSync(root);
 if(st.isSymbolicLink())throw Error('RECOVERY_REFUSED: link simbolico em '+root);
 if(st.isDirectory())for(const e of fs.readdirSync(root))assertPlainTree(path.join(root,e));
 else if(!st.isFile())throw Error('RECOVERY_REFUSED: arquivo especial em '+root);
}
export function compareTrees(expected,actual) {
 assertPlainTree(expected);assertPlainTree(actual);
 function visit(a,b) {
  const names=fs.readdirSync(a).sort(), other=fs.readdirSync(b).sort();
  if(JSON.stringify(names)!==JSON.stringify(other))throw Error('RECOVERY_REFUSED: arquivos ausentes ou extras em '+b);
  for(const n of names){const x=path.join(a,n),y=path.join(b,n);
   if(fs.statSync(x).isDirectory()){if(!fs.statSync(y).isDirectory())throw Error('RECOVERY_REFUSED: tipo divergente '+y);visit(x,y);}
   else if(!fs.statSync(y).isFile()||digest(fs.readFileSync(x))!==digest(fs.readFileSync(y)))throw Error('RECOVERY_REFUSED: arquivo modificado '+y);
  }
 }
 visit(expected,actual);
}
export async function validatePartialInstallation({root,app,cep,here,manifest,execPath=process.execPath,arch=process.arch}) {
 // Intentionally narrow: completed dependencies + exact untouched panel, before MCP registration.
 for(const name of ['installation.json','install.lock','doctor.mjs','connection.mjs'])
  if(fs.existsSync(path.join(root,name)))throw Error('RECOVERY_REFUSED: estado requer diagnostico individual: '+name);
 assertPlainTree(root);assertPlainTree(cep);
 compareTrees(path.join(here,'vendor'),app);
 compareTrees(path.join(here,'vendor/node_modules/adobe-premiere-pro-mcp/cep-plugin'),cep);
 if(await fileHash(path.join(root,'runtime/node.exe'))!==await fileHash(execPath))throw Error('RECOVERY_REFUSED: use o Node original confiavel da preparacao; runtime divergente.');
 if(await fileHash(path.join(root,'models',manifest.model.name))!==manifest.model.sha256)throw Error('RECOVERY_REFUSED: modelo divergente.');
 const gz=path.join(root,'downloads/ffmpeg.gz');
 if(await fileHash(gz)!==manifest.ffmpeg['win-x64'])throw Error('RECOVERY_REFUSED: cache FFmpeg divergente.');
 if(digest(gunzipSync(fs.readFileSync(gz)))!==await fileHash(path.join(root,'tools/ffmpeg.exe')))throw Error('RECOVERY_REFUSED: FFmpeg instalado divergente.');
 const zip=path.join(root,'downloads',arch==='arm64'?'whisper-bin-win-cpu-arm64.zip':'whisper-bin-x64.zip');
 if(await fileHash(zip)!==manifest.whisper['win-'+arch])throw Error('RECOVERY_REFUSED: cache Whisper divergente.');
 const scratch=fs.mkdtempSync(path.join(os.tmpdir(),'trombino-recovery-check-'));
 try {
  const r=spawnSync('tar.exe',['-xf',zip,'-C',scratch],{encoding:'utf8',windowsHide:true,timeout:60000});
  if(r.error||r.status!==0)throw Error('RECOVERY_REFUSED: nao foi possivel conferir o Whisper.');
  assertPlainTree(scratch);
  function find(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory()){const found=find(p);if(found)return found;}else if(e.name==='whisper-cli.exe')return p;}}
  const exe=find(scratch);if(!exe)throw Error('RECOVERY_REFUSED: Whisper ausente.');
  const allowed=['ffmpeg.exe'];
  for(const e of fs.readdirSync(path.dirname(exe),{withFileTypes:true}))if(e.isFile()){
   allowed.push(e.name);
   if(await fileHash(path.join(path.dirname(exe),e.name))!==await fileHash(path.join(root,'tools',e.name)))throw Error('RECOVERY_REFUSED: dependencia Whisper modificada '+e.name);
  }
  if(fs.readdirSync(path.join(root,'tools')).some(n=>!allowed.includes(n)))throw Error('RECOVERY_REFUSED: dependencia extra requer revisao.');
 } finally {
  // Only the fresh private temporary directory created above; never installation/user files.
  if(path.dirname(scratch)===os.tmpdir()&&path.basename(scratch).startsWith('trombino-recovery-check-'))fs.rmSync(scratch,{recursive:true,force:true});
 }
 const backup=path.join(root,'cep-settings-before.json');
 if(!fs.existsSync(backup)||!Array.isArray(JSON.parse(fs.readFileSync(backup,'utf8'))))throw Error('RECOVERY_REFUSED: backup CEP original ausente ou invalido.');
 return {recoveryEligible:true,scope:'concluir configuracao CEP e registro MCP; arquivos de midia e painel preservados'};
}
