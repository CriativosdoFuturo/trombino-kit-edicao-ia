import fs from 'node:fs';
import path from 'node:path';
import tls from 'node:tls';

export function enableSystemCA(api=tls) {
 if(typeof api.getCACertificates!=='function'||typeof api.setDefaultCACertificates!=='function') {
  throw new Error('NODE_SYSTEM_CA_REQUIRED: use Node 22.19+ ou 24.5+ com suporte aos certificados do sistema. Nao desative a validacao TLS.');
 }
 // Keep bundled and explicitly configured authorities; add only the OS trust store.
 api.setDefaultCACertificates([...api.getCACertificates('default'),...api.getCACertificates('system')]);
}

export function checkSpace(targets,io=fs) {
 const volumes=new Map();
 for(const target of targets){
  let ancestor=path.resolve(target.path);
  while(!io.existsSync(ancestor)) {
   const parent=path.dirname(ancestor);
   if(parent===ancestor)throw new Error('SPACE_CHECK_FAILED: '+target.path);
   ancestor=parent;
  }
  let stat,disk;
  try {stat=io.statSync(ancestor,{bigint:true});disk=io.statfsSync(ancestor,{bigint:true});}
  catch(e){throw new Error('SPACE_CHECK_FAILED: '+target.path+'; '+(e.code||e.message));}
  const key=String(stat.dev);
  const volume=volumes.get(key)||{free:disk.bavail*disk.bsize,required:0n,paths:[]};
  volume.required+=BigInt(target.bytes);volume.paths.push(target.path);volumes.set(key,volume);
 }
 for(const volume of volumes.values()) {
  if(volume.free<volume.required)throw new Error('INSUFFICIENT_SPACE: '+volume.paths.join(', ')+'; livres='+volume.free+' bytes; reserva necessaria='+volume.required+' bytes. Antes de baixar, ofereca liberar espaco ou instalar com --root em outro disco com espaco. Nao escolha nem apague arquivos do usuario automaticamente. O disco do perfil tambem precisa de espaco.');
 }
 return [...volumes.values()];
}
