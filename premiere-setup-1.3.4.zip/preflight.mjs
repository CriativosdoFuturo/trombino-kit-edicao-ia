import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';

export function validateIdentity(identity) {
 if (!identity || !identity.trim()) throw new Error('IDENTITY_UNAVAILABLE: nao foi possivel confirmar a conta de execucao.');
 const account=identity.trim().split('\\').at(-1);
 if (/^codexsandbox/i.test(account)) throw new Error('RESTRICTED_EXECUTION: o instalador esta executando na conta restrita '+account+'. Solicite ao cliente uma execucao autorizada na conta do usuario do Premiere. Se indisponivel, entregue o instalador para execucao manual nessa conta. Nao altere ACLs, antivirus ou politicas para contornar a restricao. Nenhuma instalacao iniciada.');
}

export function checkWindowsIdentity() {
 if(process.platform!=='win32')return;
 const r=spawnSync('whoami.exe',[],{encoding:'utf8',windowsHide:true,timeout:10000});
 if(r.status!==0)throw new Error('IDENTITY_UNAVAILABLE: whoami falhou; nenhuma instalacao iniciada.');
 validateIdentity(r.stdout);
}

export function checkWritableDirectory(target) {
 let parent=path.resolve(target);
 while(!fs.existsSync(parent)){
  const next=path.dirname(parent);
  if(next===parent)throw new Error('DIRECTORY_UNAVAILABLE: '+target);
  parent=next;
 }
 const probe=path.join(parent,'.trombino-write-check-'+crypto.randomUUID());
 let created=false;
 try{const fd=fs.openSync(probe,'wx');created=true;fs.closeSync(fd);}
 catch(e){throw new Error('WRITE_PERMISSION_REQUIRED: '+target+' ('+e.code+'). Nenhuma instalacao iniciada.');}
 finally{if(created)fs.unlinkSync(probe);}
}

export function checkExistingConfig(file) {
 if(!fs.existsSync(file))return;
 let fd;
 try{fd=fs.openSync(file,'r+');}
 catch(e){throw new Error('CONFIG_PERMISSION_REQUIRED: '+file+' ('+e.code+'). Configuracao preservada.');}
 finally{if(fd!==undefined)fs.closeSync(fd);}
}
