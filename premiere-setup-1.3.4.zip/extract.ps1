param([Parameter(Mandatory=$true)][string]$Archive,[Parameter(Mandatory=$true)][string]$Destination)
$ErrorActionPreference='Stop'
if(Test-Path -LiteralPath $Destination){throw 'Destino de extracao ja existe.'}
Expand-Archive -LiteralPath $Archive -DestinationPath $Destination
