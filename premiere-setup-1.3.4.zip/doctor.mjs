import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
const root=path.dirname(fileURLToPath(import.meta.url));
const state=JSON.parse(fs.readFileSync(path.join(root,'installation.json'),'utf8'));
let failed=false;const checks=[];
function check(name,ok){checks.push({name,ok});if(!ok)failed=true;}
for(const name of ['node','cli','ffmpeg','whisper','model','cep'])check(name,fs.existsSync(state[name]));
for(const [name,args] of [['node',['--version']],['ffmpeg',['-version']],['whisper',['--help']]]){
 const r=spawnSync(state[name],args,{encoding:'utf8',timeout:20000,windowsHide:true});check(name+' responde',r.status===0);
}
if(fs.existsSync(state.model)){const h=crypto.createHash('sha256');for await(const b of fs.createReadStream(state.model))h.update(b);check('modelo SHA256',h.digest('hex')===state.modelSha256);}
console.log(JSON.stringify({checks,dependenciesReady:!failed,connectionVerified:false,next:'Execute connection.mjs --connect para confirmar o Premiere, sem editar.'},null,2));
process.exitCode=failed?1:0;
