# Instalador Trombino — Premiere MCP com transcrição local

Este kit prepara o MCP do Adobe Premiere no **Windows** e no **macOS** a partir
de um único link. Ele foi pensado para alunos iniciantes: o Codex detecta o
sistema, executa o instalador correto, configura o painel CEP e verifica a
instalação.

## Comece aqui - instalação econômica

1. Baixe o ZIP pelo navegador e extraia-o. Não peça ao Codex para localizar ou
   baixar o GitHub.
2. No Codex, abra **a pasta extraída do instalador do Premiere**. No Mac, use o
   botão **+ > Projeto ou pasta** e selecione essa pasta.
3. Para esta instalação, use **Light/Leve** (ou `Low`, quando esse for o nome
   exibido). Se houver uma falha difícil de diagnosticar, mude para Medium.
4. Cole apenas o prompt abaixo em uma tarefa nova. Não prepare o HyperFrames,
   não renderize o teste de oito segundos e não edite vídeo nessa mesma tarefa.

## Prompt único para colar no Codex

> Leia o README.md e o AGENTS.md deste repositório. Detecte se estou no Windows
> ou no Mac e execute o instalador correspondente. Continue até o diagnóstico
> passar. Peça minha intervenção somente quando o sistema exigir aprovação ou
> quando chegar aos dois passos manuais exibidos pelo instalador. Não use APIs
> pagas e não altere nenhum projeto aberto no Premiere.

Não é necessário colar o conteúdo do README no chat. O agente lê este arquivo
diretamente da pasta aberta.

## O que o kit faz

- instala uma cópia local e versionada do `adobe-premiere-pro-mcp`;
- baixa e valida um Node.js portátil oficial, sem depender do Node do aluno;
- instala o painel **MCP Bridge (CEP)** no perfil do usuário;
- habilita somente as chaves CEP necessárias ao painel;
- registra o servidor no Codex como `premiere_pro_trombino`;
- registra e repara a integração `premiere-pro` no Claude Desktop/Cowork;
- instala FFmpeg, whisper.cpp e o modelo multilíngue `small`;
- adiciona `transcribe_media` e `read_local_transcript` ao catálogo do MCP;
- transcreve localmente com timestamps e cache, sem enviar áudio a uma API;
- ativa o **modo Premiere econômico**, mantendo apenas esse MCP visível e ocultando
  temporariamente os outros MCPs, apps e conectores;
- guarda o estado anterior para restaurar as outras ferramentas sem desinstalá-las;
- executa o diagnóstico e grava um relatório local;
- mantém a instalação via npm apenas como recuperação documentada.

Nenhuma API paga é configurada. No Windows a instalação fica no perfil do
usuário. No macOS, o Homebrew oficial pode pedir a senha do computador ao ser
instalado pela primeira vez. O modelo tem cerca de 466 MB e é baixado uma vez.

## Execução manual, se necessário

O terminal precisa executar no computador onde o Premiere está instalado.
Uma pasta conectada ao Claude não garante isso: se a execução estiver numa VM
Linux, use o Terminal do Mac ou o PowerShell do Windows diretamente. O instalador
de Mac recusa Linux antes de baixar ou modificar arquivos.

No Mac, no Finder, clique com o botão direito na pasta extraída e escolha
**Nova Janela do Terminal na Pasta**. Cole o comando abaixo e pressione Enter.

### Windows

Abra o PowerShell nesta pasta e execute:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
```

### macOS

Abra o Terminal nesta pasta e execute:

```bash
bash ./install-mac.sh
```

## As duas ações do aluno

Quando o instalador terminar, ele mostrará claramente:

1. Feche completamente e abra novamente o Codex ou Claude e o Premiere.
2. No Premiere, abra **Janela > Extensões > MCP Bridge (CEP)**, confirme a pasta
   indicada e clique em **Start Bridge**.

Depois, no Codex, peça:

> Execute `verify_premiere_connection`. Não altere o projeto.

Para confirmar a decupagem, peça depois:

> Use `transcribe_media` uma vez na mídia da sequência ativa, reutilize o cache
> e mostre apenas os primeiros cinco segmentos. Não altere a timeline.

## Modo Premiere econômico

O modo econômico evita que o Codex carregue catálogos enormes de ferramentas
antes do primeiro corte. Durante a edição no Premiere, apenas
`premiere_pro_trombino` permanece ativo. CapCut, Runway, outros MCPs e apps ficam
temporariamente ocultos, mas continuam instalados.

Quando terminar a edição e quiser suas ferramentas anteriores de volta, peça ao
Codex para executar o script de restauração exibido pelo instalador. Depois,
reinicie o Codex. Para editar novamente no Premiere, execute o script de ativação
instalado na mesma pasta e reinicie o Codex.

O instalador salva um backup do `config.toml` e restaura somente as opções que
ele alterou. Projetos, mídias, credenciais e configurações internas dos outros
MCPs não são apagados.

## Compatibilidade fixada

- Instalador Trombino: `1.2.1`
- MCP do Premiere: `1.2.8`
- Node.js portátil: `24.21.0`
- Requisito declarado pelo MCP: Premiere Pro 2020 ou superior
- Pacotes: Windows x64/ARM64 e macOS Intel/Apple Silicon
- Transcrição: `whisper.cpp` local, modelo multilíngue `small`

Consulte [SUPORTE.md](SUPORTE.md) quando o diagnóstico não passar.

## Custo e validação

A transcrição roda localmente, sem API paga de voz. O uso do Codex ou Claude
para analisar o texto e coordenar ferramentas continua sujeito ao plano e à
cobrança do provedor. Este kit não garante um preço por edição.

O caso acompanhado no Mac Apple Silicon confirmou painel, conexão e catálogo
de transcrição após correções manuais na versão 1.2.0. A versão 1.2.1 incorpora
essas correções; isso não equivale a validar cada versão de macOS, Windows ou
Premiere. Veja VALIDACAO.md para os testes desta distribuição.
