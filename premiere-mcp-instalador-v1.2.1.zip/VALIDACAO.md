# Validação 1.2.1 — 21/09/2026

## Correções verificadas
- Node portátil adicionado ao PATH dos processos filhos em Mac e Windows.
- Diagnóstico monta o caminho com dirname/join; casos Windows e macOS com espaços verificados.
- Importação real do catálogo vendorizado passou, incluindo transcribe_media e read_local_transcript.
- Sintaxe PowerShell do instalador e sintaxe Node do diagnóstico verificadas.
- Mac recusa plataforma diferente de Darwin antes de criar diretórios ou baixar arquivos.
- Windows interrompe em falha do Node e da instalação CEP, restaurando PATH da sessão ao terminar.
- Arquivo ZIP conferido por CRC, inventário e SHA-256.

## Limites da verificação
O Mac do aluno confirmou conexão, painel e ferramentas na versão 1.2.0 após
ajustes manuais. O aluno foi reportado como resolvido pelo instrutor. Não foi
executada nesta máquina Windows uma instalação completa do pacote 1.2.1 em Mac.
Não há validação física de todas as combinações de sistema/arquitetura/editor.
O catálogo disponível não prova a qualidade de uma decupagem; revisar os cortes.

Existe relato de antivírus bloqueando a v1.0.0; o nome da ameaça ainda não foi
fornecido. Esta publicação não afirma resolver nem descartar essa detecção.
